import { useEffect, useState } from 'react'
import { Modal } from '../components/ui/Modal'
import type { DocCategory, DocSettings, Margins, Orientation, PageSize } from '../types'
import { CATEGORIES, FONT_FAMILIES, FONT_SIZES, LINE_HEIGHTS } from '../utils/constants'
import { PAGE_SIZES, getPageDims } from '../utils/page'

interface Props {
  open: boolean
  onClose: () => void
  settings: DocSettings
  category: DocCategory
  onSave: (settings: DocSettings, category: DocCategory) => void
}

const MARGIN_FIELDS: { key: keyof Margins; label: string }[] = [
  { key: 'top', label: 'Atas' },
  { key: 'bottom', label: 'Bawah' },
  { key: 'left', label: 'Kiri' },
  { key: 'right', label: 'Kanan' },
]

const clamp = (n: number, min: number, max: number) => Math.min(max, Math.max(min, n))

export function DocumentSettingsDialog({ open, onClose, settings, category, onSave }: Props) {
  const [s, setS] = useState(settings)
  const [cat, setCat] = useState(category)
  const [margins, setMargins] = useState<Record<keyof Margins, string>>({ top: '', bottom: '', left: '', right: '' })

  useEffect(() => {
    if (!open) return
    setS(settings)
    setCat(category)
    setMargins({
      top: String(settings.margins.top),
      bottom: String(settings.margins.bottom),
      left: String(settings.margins.left),
      right: String(settings.margins.right),
    })
  }, [open, settings, category])

  const save = () => {
    const dims = getPageDims(s)
    const parse = (v: string, fallback: number) => {
      const n = parseFloat(v.replace(',', '.'))
      return clamp(Number.isFinite(n) ? n : fallback, 0.5, 6)
    }
    let m: Margins = {
      top: parse(margins.top, 2.54),
      bottom: parse(margins.bottom, 2.54),
      left: parse(margins.left, 2.54),
      right: parse(margins.right, 2.54),
    }
    // Sisakan minimal 5 cm lebar dan tinggi area tulis.
    if (dims.width - m.left - m.right < 5) m = { ...m, left: 2.54, right: 2.54 }
    if (dims.height - m.top - m.bottom < 5) m = { ...m, top: 2.54, bottom: 2.54 }
    onSave({ ...s, margins: m, header: s.header.trim(), footer: s.footer.trim() }, cat)
    onClose()
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Tata letak dan dokumen"
      size="lg"
      footer={
        <>
          <button type="button" className="btn btn-subtle" onClick={onClose}>Batal</button>
          <button type="button" className="btn btn-primary" onClick={save}>Terapkan</button>
        </>
      }
    >
      <div className="grid grid-cols-1 gap-x-4 gap-y-3 sm:grid-cols-2">
        <div>
          <label className="label" htmlFor="ds-size">Ukuran kertas</label>
          <select id="ds-size" className="input" value={s.pageSize} onChange={(e) => setS({ ...s, pageSize: e.target.value as PageSize })}>
            {Object.entries(PAGE_SIZES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
          </select>
        </div>
        <div>
          <label className="label" htmlFor="ds-or">Orientasi</label>
          <select id="ds-or" className="input" value={s.orientation} onChange={(e) => setS({ ...s, orientation: e.target.value as Orientation })}>
            <option value="portrait">Potret</option>
            <option value="landscape">Lanskap</option>
          </select>
        </div>

        <fieldset className="sm:col-span-2">
          <legend className="label">Margin (cm)</legend>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {MARGIN_FIELDS.map((f) => (
              <div key={f.key}>
                <label className="sr-only" htmlFor={`m-${f.key}`}>Margin {f.label}</label>
                <div className="relative">
                  <input
                    id={`m-${f.key}`}
                    className="input pr-12"
                    inputMode="decimal"
                    value={margins[f.key]}
                    onChange={(e) => setMargins({ ...margins, [f.key]: e.target.value })}
                  />
                  <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted">{f.label}</span>
                </div>
              </div>
            ))}
          </div>
        </fieldset>

        <div>
          <label className="label" htmlFor="ds-font">Font dasar</label>
          <select id="ds-font" className="input" value={s.fontFamily} onChange={(e) => setS({ ...s, fontFamily: e.target.value })}>
            {FONT_FAMILIES.map((f) => <option key={f.name} value={f.name}>{f.name}</option>)}
          </select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label" htmlFor="ds-fs">Ukuran (pt)</label>
            <select id="ds-fs" className="input" value={s.fontSize} onChange={(e) => setS({ ...s, fontSize: Number(e.target.value) })}>
              {FONT_SIZES.map((n) => <option key={n} value={n}>{n}</option>)}
            </select>
          </div>
          <div>
            <label className="label" htmlFor="ds-lh">Spasi baris</label>
            <select id="ds-lh" className="input" value={s.lineHeight} onChange={(e) => setS({ ...s, lineHeight: Number(e.target.value) })}>
              {LINE_HEIGHTS.map((n) => <option key={n} value={n}>{n}</option>)}
            </select>
          </div>
        </div>

        <div>
          <label className="label" htmlFor="ds-header">Header (kanan atas)</label>
          <input id="ds-header" className="input" value={s.header} onChange={(e) => setS({ ...s, header: e.target.value })} placeholder="mis. Rahasia" />
        </div>
        <div>
          <label className="label" htmlFor="ds-footer">Footer (tengah bawah)</label>
          <input id="ds-footer" className="input" value={s.footer} onChange={(e) => setS({ ...s, footer: e.target.value })} placeholder="mis. Nama Perusahaan" />
        </div>

        <label className="flex items-center gap-2 text-sm sm:col-span-1">
          <input type="checkbox" className="h-4 w-4 accent-[rgb(var(--brand))]" checked={s.showPageNumber} onChange={(e) => setS({ ...s, showPageNumber: e.target.checked })} />
          Tampilkan nomor halaman
        </label>
        <div>
          <label className="label" htmlFor="ds-cat">Kategori</label>
          <select id="ds-cat" className="input" value={cat} onChange={(e) => setCat(e.target.value as DocCategory)}>
            {CATEGORIES.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}
          </select>
        </div>
      </div>
      <p className="mt-4 text-xs text-muted">
        Header, footer, dan nomor halaman tampil di berkas DOCX dan PDF. Garis putus-putus di editor adalah perkiraan
        batas halaman; pemisahan halaman final dihitung saat ekspor.
      </p>
    </Modal>
  )
}
