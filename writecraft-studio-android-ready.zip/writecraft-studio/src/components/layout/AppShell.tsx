import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { Menu } from 'lucide-react'
import type { Route } from '../../hooks/useHashRoute'
import { Sidebar } from './Sidebar'

const ShellContext = createContext<{ openSidebar: () => void }>({ openSidebar: () => {} })
export const useShell = () => useContext(ShellContext)

export function AppShell({ route, children }: { route: Route; children: ReactNode }) {
  const [open, setOpen] = useState(false)
  const key = route.name === 'editor' ? `editor:${route.id}` : route.name

  // Tutup laci sidebar (layar kecil) setiap kali pindah halaman.
  useEffect(() => setOpen(false), [key])

  const value = useMemo(() => ({ openSidebar: () => setOpen(true) }), [])
  return (
    <ShellContext.Provider value={value}>
      <div className="flex h-full">
        <Sidebar open={open} onClose={() => setOpen(false)} route={route} />
        <main className="flex h-full min-w-0 flex-1 flex-col">{children}</main>
      </div>
    </ShellContext.Provider>
  )
}

/** Tombol hamburger yang hanya muncul di layar kecil. */
export function SidebarToggle() {
  const { openSidebar } = useShell()
  return (
    <button type="button" className="btn-icon lg:hidden" onClick={openSidebar} aria-label="Buka menu">
      <Menu size={20} />
    </button>
  )
}
