import type { DocCategory, DocNode, DocumentRecord } from '../types'
import { getTemplate } from '../templates'
import { uid } from '../utils/format'
import { defaultDocSettings } from './settings'
import { putDocument } from './storage'

/** Buat dokumen baru dari template dan simpan ke IndexedDB. */
export async function createFromTemplate(templateId: string): Promise<DocumentRecord> {
  const tpl = getTemplate(templateId)
  const base = defaultDocSettings()
  const now = Date.now()
  const record: DocumentRecord = {
    id: uid(),
    title: tpl.title,
    category: tpl.category,
    content: tpl.build(),
    settings: {
      ...base,
      ...tpl.settings,
      margins: { ...(tpl.settings?.margins ?? base.margins) },
    },
    createdAt: now,
    updatedAt: now,
  }
  await putDocument(record)
  return record
}

/** Buat dokumen dari isi yang sudah ada (mis. hasil impor DOCX). */
export async function createFromContent(
  title: string,
  content: DocNode,
  category: DocCategory = 'umum',
): Promise<DocumentRecord> {
  const now = Date.now()
  const record: DocumentRecord = {
    id: uid(),
    title: title.trim() || 'Dokumen impor',
    category,
    content,
    settings: defaultDocSettings(),
    createdAt: now,
    updatedAt: now,
  }
  await putDocument(record)
  return record
}
