import { useEffect, useRef, useState, type ReactNode } from 'react'
import { Download, Trash2, Upload } from 'lucide-react'
import { PageHeader } from '../components/layout/PageHeader'
import { Modal } from '../components/ui/Modal'
import { useToast } from '../components/ui/Toast'
import { useAppSettings } from '../hooks/useAppSettings'
import { updateSettings } from '../services/settings'
import { clearAllDocuments, exportBackup, importBackup, listDocuments } from '../services/storage'
import type { Orientation, PageSize, ThemeMode } from '../types'
import { FONT_FAMILIES, FONT_SIZES, LINE_HEIGHTS } from '../utils/constants'
import { downloadBlob } from '../utils/format'
import { PAGE_SIZES } from '../utils/page'

function Section({ title, hint, children }: { title: string; hint?: string; children: ReactNode }) {
  return (
    <section className="rounded-xl border border-line bg-surface p-4 sm:p-5">
      <h3 className="text-sm font-semibold">{title}</h3>
      {hint && <p className="mt-0.5 text-sm text-muted">{hint}</p>}
      <div className="mt-4">{children}</div>
    </section>
  )
}

export function SettingsPage() {
  const s = useAppSettings()
  const toast = useToast()
  const fileRef = useRef<HTMLInputElement>(null)
  const [confirmClear, setConfirmClear] = useState(false)
  const [usage, setUsage] = useState<string>('')
  const [count, setCount] = useState(0)

  useEffect(() => {
    void (async () => {
      try {
        setCount((await listDocuments()).length)
        const est = await navigator.storage?.estimate?.()
        if (est?.usage != null) setUsage(`${(est.usage / 1024 / 1024).toFixed(1)} MB`)
      } catch {
        /* abaikan */
      }
    })()
  }, [])

  const backup = async () => {
    try {
      const json = await exportBackup()
      const stamp = new Date().toISOString().slice(0, 10)
      downloadBlob(new Blob([json], { type: 'application/json' }), `writecraft-cadangan-${stamp}.json`)
      toast('Cadangan diunduh.')
    } catch {
      toast('Gagal membuat cadangan.', 'error')
    }
  }

  const restore = async (file: File | undefined) => {
    if (!file) return
    try {
      const n = await importBackup(await file.text())
      setCount((await listDocuments()).length)
      toast(`${n} dokumen dipulihkan.`)
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Cadangan tidak dapat dibaca.', 'error')
    }
  }

  return (
    <>
      <PageHeader>
        <h1 className="text-sm font-semibold">Pengaturan</h1>
      </PageHeader>
      <div className="thin-scroll flex-1 overflow-y-auto">
        <div className="mx-auto max-w-2xl space-y-4 px-4 py-6 sm:px-6 sm:py-10">
          <Section title="Tampilan">
            <label className="label" htmlFor="theme">Tema</label>
            <select id="theme" className="input" value={s.theme} onChange={(e) => updateSettings({ theme: e.target.value as ThemeMode })}>
              <option value="system">Ikuti sistem</option>
              <option value="light">Terang</option>
              <option value="dark">Gelap</option>
            </select>
          </Section>

          <Section title="Dokumen baru" hint="Dipakai sebagai nilai awal setiap kali Anda membuat dokumen. Dokumen yang sudah ada tidak berubah.">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className="label" htmlFor="ps">Ukuran kertas</label>
                <select id="ps" className="input" value={s.defaultPageSize} onChange={(e) => updateSettings({ defaultPageSize: e.target.value as PageSize })}>
                  {Object.entries(PAGE_SIZES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
                </select>
              </div>
              <div>
                <label className="label" htmlFor="or">Orientasi</label>
                <select id="or" className="input" value={s.defaultOrientation} onChange={(e) => updateSettings({ defaultOrientation: e.target.value as Orientation })}>
                  <option value="portrait">Potret</option>
                  <option value="landscape">Lanskap</option>
                </select>
              </div>
              <div>
                <label className="label" htmlFor="ff">Font</label>
                <select id="ff" className="input" value={s.defaultFontFamily} onChange={(e) => updateSettings({ defaultFontFamily: e.target.value })}>
                  {FONT_FAMILIES.map((f) => <option key={f.name} value={f.name}>{f.name}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label" htmlFor="fs">Ukuran (pt)</label>
                  <select id="fs" className="input" value={s.defaultFontSize} onChange={(e) => updateSettings({ defaultFontSize: Number(e.target.value) })}>
                    {FONT_SIZES.map((n) => <option key={n} value={n}>{n}</option>)}
                  </select>
                </div>
                <div>
                  <label className="label" htmlFor="lh">Spasi baris</label>
                  <select id="lh" className="input" value={s.defaultLineHeight} onChange={(e) => updateSettings({ defaultLineHeight: Number(e.target.value) })}>
                    {LINE_HEIGHTS.map((n) => <option key={n} value={n}>{n}</option>)}
                  </select>
                </div>
              </div>
            </div>
          </Section>

          <Section title="Simpan otomatis" hint="Jeda setelah Anda berhenti mengetik sebelum perubahan disimpan.">
            <label className="label" htmlFor="as">Jeda</label>
            <select id="as" className="input" value={s.autosaveDelay} onChange={(e) => updateSettings({ autosaveDelay: Number(e.target.value) })}>
              <option value={400}>Cepat (0,4 detik)</option>
              <option value={800}>Normal (0,8 detik)</option>
              <option value={2000}>Santai (2 detik)</option>
              <option value={5000}>Lambat (5 detik)</option>
            </select>
          </Section>

          <Section
            title="Data dan cadangan"
            hint={`${count} dokumen tersimpan di browser ini${usage ? ` · ${usage} terpakai` : ''}. Data tidak dikirim ke server mana pun.`}
          >
            <div className="flex flex-wrap gap-2">
              <button type="button" className="btn btn-subtle" onClick={() => void backup()}>
                <Download size={16} /> Unduh cadangan
              </button>
              <button type="button" className="btn btn-subtle" onClick={() => fileRef.current?.click()}>
                <Upload size={16} /> Pulihkan dari cadangan
              </button>
              <input
                ref={fileRef}
                type="file"
                accept="application/json,.json"
                className="hidden"
                onChange={(e) => {
                  void restore(e.target.files?.[0])
                  e.target.value = ''
                }}
              />
              <button type="button" className="btn btn-ghost text-red-600" onClick={() => setConfirmClear(true)}>
                <Trash2 size={16} /> Hapus semua dokumen
              </button>
            </div>
          </Section>

          <p className="px-1 text-center text-xs text-muted">WriteCraft Studio v1.0 · Lisensi MIT</p>
        </div>
      </div>

      <Modal
        open={confirmClear}
        onClose={() => setConfirmClear(false)}
        title="Hapus semua dokumen?"
        size="sm"
        footer={
          <>
            <button type="button" className="btn btn-subtle" onClick={() => setConfirmClear(false)}>Batal</button>
            <button
              type="button"
              className="btn btn-danger"
              onClick={async () => {
                await clearAllDocuments()
                setCount(0)
                setConfirmClear(false)
                toast('Semua dokumen dihapus.')
              }}
            >
              Hapus semua
            </button>
          </>
        }
      >
        <p className="text-sm">Semua dokumen di browser ini akan dihapus permanen. Unduh cadangan lebih dulu bila perlu.</p>
      </Modal>
    </>
  )
}
