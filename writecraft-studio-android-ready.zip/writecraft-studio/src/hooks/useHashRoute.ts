import { useEffect, useState } from 'react'

export type Route =
  | { name: 'dashboard' }
  | { name: 'editor'; id: string }
  | { name: 'settings' }

function parse(hash: string): Route {
  const path = hash.replace(/^#/, '') || '/'
  const m = /^\/doc\/([^/?]+)/.exec(path)
  if (m) return { name: 'editor', id: decodeURIComponent(m[1]) }
  if (path.startsWith('/settings')) return { name: 'settings' }
  return { name: 'dashboard' }
}

/** Pindah halaman, mis. go('/doc/abc'). */
export function go(path: string): void {
  window.location.hash = path
}

export const paths = {
  dashboard: '/',
  settings: '/settings',
  doc: (id: string) => `/doc/${encodeURIComponent(id)}`,
}

export function useHashRoute(): Route {
  const [route, setRoute] = useState<Route>(() => parse(window.location.hash))
  useEffect(() => {
    const onChange = () => setRoute(parse(window.location.hash))
    window.addEventListener('hashchange', onChange)
    return () => window.removeEventListener('hashchange', onChange)
  }, [])
  return route
}
