import type { ReactNode } from 'react'
import { SidebarToggle } from './AppShell'

export function PageHeader({ children }: { children?: ReactNode }) {
  return (
    <header
      className="flex h-14 shrink-0 items-center gap-2 border-b border-line bg-surface px-3"
      style={{ paddingTop: 'env(safe-area-inset-top)' }}
    >
      <SidebarToggle />
      {children}
    </header>
  )
}
