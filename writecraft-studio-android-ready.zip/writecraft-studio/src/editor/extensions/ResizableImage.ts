import Image from '@tiptap/extension-image'

/** Gambar dengan atribut lebar (px) dan perataan (kiri/tengah/kanan). */
export const ResizableImage = Image.extend({
  addAttributes() {
    return {
      ...this.parent?.(),
      width: {
        default: null,
        parseHTML: (el: HTMLElement) => {
          const v = parseFloat(el.getAttribute('width') ?? el.style.width ?? '')
          return Number.isFinite(v) ? v : null
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        renderHTML: (a: Record<string, any>) =>
          a.width ? { width: a.width, style: `width: ${a.width}px; max-width: 100%; height: auto` } : {},
      },
      align: {
        default: 'left',
        parseHTML: (el: HTMLElement) => el.getAttribute('data-align') || 'left',
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        renderHTML: (a: Record<string, any>) => {
          const align = a.align || 'left'
          const style =
            align === 'center' ? 'margin-left: auto; margin-right: auto' : align === 'right' ? 'margin-left: auto' : ''
          return { 'data-align': align, ...(style ? { style } : {}) }
        },
      },
    }
  },
})
