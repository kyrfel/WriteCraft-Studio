export interface RasterImage {
  dataUrl: string
  bytes: Uint8Array
  format: 'PNG' | 'JPEG'
  width: number
  height: number
}
export type ImageMap = Map<string, RasterImage>

const MAX_EXPORT_WIDTH = 2000

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image()
    if (!src.startsWith('data:')) img.crossOrigin = 'anonymous'
    img.onload = () => resolve(img)
    img.onerror = () => reject(new Error('Gambar tidak dapat dimuat'))
    img.src = src
  })
}

export function dataUrlToBytes(dataUrl: string): Uint8Array {
  const b64 = dataUrl.slice(dataUrl.indexOf(',') + 1)
  const bin = atob(b64)
  const bytes = new Uint8Array(bin.length)
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i)
  return bytes
}

/**
 * Ubah gambar apa pun (PNG/JPEG/GIF/WebP/SVG) menjadi PNG atau JPEG lewat canvas,
 * karena hanya format itulah yang didukung DOCX dan PDF.
 */
export async function rasterize(src: string): Promise<RasterImage | null> {
  try {
    const img = await loadImage(src)
    const naturalW = img.naturalWidth || img.width
    const naturalH = img.naturalHeight || img.height
    if (!naturalW || !naturalH) return null
    const scale = Math.min(1, MAX_EXPORT_WIDTH / naturalW)
    const width = Math.max(1, Math.round(naturalW * scale))
    const height = Math.max(1, Math.round(naturalH * scale))
    const canvas = document.createElement('canvas')
    canvas.width = width
    canvas.height = height
    const ctx = canvas.getContext('2d')
    if (!ctx) return null
    const isJpeg = /^data:image\/jpe?g/i.test(src)
    if (isJpeg) {
      ctx.fillStyle = '#fff'
      ctx.fillRect(0, 0, width, height)
    }
    ctx.drawImage(img, 0, 0, width, height)
    const dataUrl = canvas.toDataURL(isJpeg ? 'image/jpeg' : 'image/png', 0.92)
    return { dataUrl, bytes: dataUrlToBytes(dataUrl), format: isJpeg ? 'JPEG' : 'PNG', width, height }
  } catch {
    return null
  }
}

export async function rasterizeAll(srcs: Iterable<string>): Promise<ImageMap> {
  const map: ImageMap = new Map()
  await Promise.all(
    Array.from(srcs).map(async (src) => {
      const r = await rasterize(src)
      if (r) map.set(src, r)
    }),
  )
  return map
}

/** Baca file gambar dari perangkat, perkecil bila terlalu lebar, kembalikan sebagai data URL. */
export async function fileToImage(
  file: File,
  maxWidth = 1600,
): Promise<{ src: string; width: number; height: number }> {
  const original = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(String(reader.result))
    reader.onerror = () => reject(new Error('Gagal membaca berkas gambar'))
    reader.readAsDataURL(file)
  })
  const img = await loadImage(original)
  const w = img.naturalWidth || img.width
  const h = img.naturalHeight || img.height
  const keepOriginal = ['image/jpeg', 'image/png', 'image/gif'].includes(file.type) && w <= maxWidth
  if (keepOriginal) return { src: original, width: w, height: h }
  const scale = Math.min(1, maxWidth / w)
  const canvas = document.createElement('canvas')
  canvas.width = Math.max(1, Math.round(w * scale))
  canvas.height = Math.max(1, Math.round(h * scale))
  const ctx = canvas.getContext('2d')
  if (!ctx) return { src: original, width: w, height: h }
  const jpeg = file.type === 'image/jpeg'
  if (jpeg) {
    ctx.fillStyle = '#fff'
    ctx.fillRect(0, 0, canvas.width, canvas.height)
  }
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
  return { src: canvas.toDataURL(jpeg ? 'image/jpeg' : 'image/png', 0.9), width: canvas.width, height: canvas.height }
}
