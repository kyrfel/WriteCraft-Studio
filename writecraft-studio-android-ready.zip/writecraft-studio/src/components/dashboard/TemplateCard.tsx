import type { DocTemplate } from '../../templates'
import { TemplateThumb } from './TemplateThumb'

export function TemplateCard({ template, onUse, busy }: { template: DocTemplate; onUse: () => void; busy: boolean }) {
  return (
    <button
      type="button"
      onClick={onUse}
      disabled={busy}
      className="group flex items-center gap-3 rounded-xl border border-line bg-surface p-3 text-left transition-colors hover:border-brand/50 hover:bg-surface2 disabled:opacity-60"
    >
      <TemplateThumb id={template.id} className="w-12 shrink-0" />
      <span className="min-w-0">
        <span className="block truncate text-sm font-semibold">{template.name}</span>
        <span className="mt-0.5 block text-xs leading-snug text-muted">{template.description}</span>
      </span>
    </button>
  )
}
