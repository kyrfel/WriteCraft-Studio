import { useEffect, useState } from 'react'
import { PageHeader } from '../components/layout/PageHeader'
import { EditorWorkspace } from '../editor/EditorWorkspace'
import { go, paths } from '../hooks/useHashRoute'
import { getDocument } from '../services/storage'
import type { DocumentRecord } from '../types'

type State =
  | { status: 'loading' }
  | { status: 'missing' }
  | { status: 'error' }
  | { status: 'ready'; doc: DocumentRecord }

export function EditorPage({ id }: { id: string }) {
  const [state, setState] = useState<State>({ status: 'loading' })

  useEffect(() => {
    let alive = true
    setState({ status: 'loading' })
    getDocument(id)
      .then((doc) => alive && setState(doc ? { status: 'ready', doc } : { status: 'missing' }))
      .catch(() => alive && setState({ status: 'error' }))
    return () => {
      alive = false
    }
  }, [id])

  if (state.status === 'ready') return <EditorWorkspace key={state.doc.id} initial={state.doc} />

  return (
    <>
      <PageHeader />
      <div className="flex flex-1 items-center justify-center p-6 text-center">
        {state.status === 'loading' ? (
          <p className="text-sm text-muted">Membuka dokumen…</p>
        ) : (
          <div>
            <p className="font-semibold">
              {state.status === 'missing' ? 'Dokumen tidak ditemukan' : 'Dokumen tidak dapat dibuka'}
            </p>
            <p className="mt-1 text-sm text-muted">
              {state.status === 'missing'
                ? 'Dokumen mungkin sudah dihapus atau tersimpan di browser lain.'
                : 'Penyimpanan browser tidak dapat diakses.'}
            </p>
            <button type="button" className="btn btn-primary mt-4" onClick={() => go(paths.dashboard)}>
              Kembali ke dasbor
            </button>
          </div>
        )}
      </div>
    </>
  )
}
