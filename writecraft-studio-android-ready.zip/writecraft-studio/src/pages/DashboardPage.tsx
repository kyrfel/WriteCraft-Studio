import { useMemo, useRef, useState } from 'react'
import { FilePlus2, FileUp, Search } from 'lucide-react'
import { DocumentCard } from '../components/dashboard/DocumentCard'
import { TemplateCard } from '../components/dashboard/TemplateCard'
import { PageHeader } from '../components/layout/PageHeader'
import { Modal } from '../components/ui/Modal'
import { useToast } from '../components/ui/Toast'
import { go, paths } from '../hooks/useHashRoute'
import { useDocuments } from '../hooks/useDocuments'
import { createFromContent, createFromTemplate } from '../services/documents'
import { downloadDocument, type ExportKind } from '../services/download'
import { deleteDocument, duplicateDocument, renameDocument } from '../services/storage'
import { TEMPLATES } from '../templates'
import type { DocCategory, DocumentRecord } from '../types'
import { CATEGORIES } from '../utils/constants'
import { docToPlainText } from '../utils/doc'
import { greeting } from '../utils/format'

export function DashboardPage() {
  const { docs, loading, error } = useDocuments()
  const toast = useToast()
  const fileRef = useRef<HTMLInputElement>(null)
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState<DocCategory | 'all'>('all')
  const [busy, setBusy] = useState(false)
  const [renaming, setRenaming] = useState<DocumentRecord | null>(null)
  const [renameValue, setRenameValue] = useState('')
  const [deleting, setDeleting] = useState<DocumentRecord | null>(null)

  const searchIndex = useMemo(() => {
    const map = new Map<string, string>()
    docs.forEach((d) => map.set(d.id, `${d.title}\n${docToPlainText(d.content)}`.toLowerCase()))
    return map
  }, [docs])

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    return docs.filter(
      (d) => (category === 'all' || d.category === category) && (!q || searchIndex.get(d.id)?.includes(q)),
    )
  }, [docs, query, category, searchIndex])

  const counts = useMemo(() => {
    const c: Record<string, number> = {}
    docs.forEach((d) => (c[d.category] = (c[d.category] ?? 0) + 1))
    return c
  }, [docs])

  const run = async (fn: () => Promise<void>, failMessage: string) => {
    setBusy(true)
    try {
      await fn()
    } catch (e) {
      toast(e instanceof Error && e.message ? e.message : failMessage, 'error')
    } finally {
      setBusy(false)
    }
  }

  const useTemplate = (id: string) =>
    run(async () => {
      const rec = await createFromTemplate(id)
      go(paths.doc(rec.id))
    }, 'Gagal membuat dokumen.')

  const onImport = (file: File | undefined) => {
    if (!file) return
    void run(async () => {
      if (!/\.docx$/i.test(file.name)) throw new Error('Pilih berkas berekstensi .docx.')
      const { importDocx } = await import('../services/importDocx')
      const { title, content, warnings } = await importDocx(file)
      const rec = await createFromContent(title, content)
      if (warnings.length) toast(`Diimpor dengan ${warnings.length} peringatan format.`)
      go(paths.doc(rec.id))
    }, 'Berkas DOCX tidak dapat dibaca.')
  }

  const exportDoc = (doc: DocumentRecord, kind: ExportKind) =>
    run(async () => {
      await downloadDocument(doc, kind)
      toast(`${doc.title}.${kind} diunduh.`)
    }, `Gagal mengekspor ${kind.toUpperCase()}.`)

  const submitRename = () =>
    run(async () => {
      if (renaming) await renameDocument(renaming.id, renameValue)
      setRenaming(null)
    }, 'Gagal mengganti nama.')

  const confirmDelete = () =>
    run(async () => {
      if (deleting) await deleteDocument(deleting.id)
      toast('Dokumen dihapus.')
      setDeleting(null)
    }, 'Gagal menghapus dokumen.')

  return (
    <>
      <PageHeader>
        <h1 className="text-sm font-semibold lg:hidden">Dasbor</h1>
      </PageHeader>

      <div className="thin-scroll flex-1 overflow-y-auto">
        <div className="mx-auto w-full max-w-6xl px-4 py-6 sm:px-8 sm:py-10">
          <section className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <h2 className="font-serif text-3xl font-semibold tracking-tight sm:text-4xl">{greeting()}.</h2>
              <p className="mt-1.5 text-muted">Tulis sesuatu hari ini, atau lanjutkan dokumen yang sudah ada.</p>
            </div>
            <div className="flex gap-2">
              <button type="button" className="btn btn-primary" disabled={busy} onClick={() => void useTemplate('blank')}>
                <FilePlus2 size={16} /> Dokumen baru
              </button>
              <button type="button" className="btn btn-subtle" disabled={busy} onClick={() => fileRef.current?.click()}>
                <FileUp size={16} /> Impor DOCX
              </button>
              <input
                ref={fileRef}
                type="file"
                accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                className="hidden"
                onChange={(e) => {
                  onImport(e.target.files?.[0])
                  e.target.value = ''
                }}
              />
            </div>
          </section>

          <section className="mt-9">
            <h3 className="mb-3 text-sm font-semibold">Mulai dari template</h3>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {TEMPLATES.map((t) => (
                <TemplateCard key={t.id} template={t} busy={busy} onUse={() => void useTemplate(t.id)} />
              ))}
            </div>
          </section>

          <section className="mt-10">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <h3 className="text-sm font-semibold">Dokumen terbaru</h3>
              <div className="relative sm:w-72">
                <Search size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
                <input
                  className="input pl-9"
                  type="search"
                  placeholder="Cari judul atau isi dokumen"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  aria-label="Cari dokumen"
                />
              </div>
            </div>

            <div className="no-scrollbar -mx-4 mt-3 flex gap-1.5 overflow-x-auto px-4 sm:mx-0 sm:flex-wrap sm:px-0" role="tablist" aria-label="Kategori">
              {[{ id: 'all' as const, label: 'Semua' }, ...CATEGORIES].map((c) => {
                const n = c.id === 'all' ? docs.length : counts[c.id] ?? 0
                const active = category === c.id
                return (
                  <button
                    key={c.id}
                    type="button"
                    role="tab"
                    aria-selected={active}
                    onClick={() => setCategory(c.id)}
                    className={`shrink-0 rounded-full border px-3 py-1 text-sm transition-colors ${
                      active ? 'border-brand bg-brand text-brand-fg' : 'border-line bg-surface hover:bg-surface2'
                    }`}
                  >
                    {c.label}
                    <span className={`ml-1.5 text-xs ${active ? 'opacity-80' : 'text-muted'}`}>{n}</span>
                  </button>
                )
              })}
            </div>

            {error && <p className="mt-6 rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950 dark:text-red-300">{error}</p>}

            {!loading && !error && filtered.length === 0 && (
              <div className="mt-6 rounded-xl border border-dashed border-line p-10 text-center">
                <p className="font-medium">{docs.length === 0 ? 'Belum ada dokumen' : 'Tidak ada dokumen yang cocok'}</p>
                <p className="mt-1 text-sm text-muted">
                  {docs.length === 0
                    ? 'Pilih template di atas atau buat dokumen kosong untuk mulai menulis.'
                    : 'Coba kata kunci lain atau pilih kategori Semua.'}
                </p>
              </div>
            )}

            <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {filtered.map((d) => (
                <DocumentCard
                  key={d.id}
                  doc={d}
                  onOpen={() => go(paths.doc(d.id))}
                  onRename={() => {
                    setRenaming(d)
                    setRenameValue(d.title)
                  }}
                  onDuplicate={() =>
                    void run(async () => {
                      await duplicateDocument(d.id)
                      toast('Dokumen diduplikasi.')
                    }, 'Gagal menduplikasi dokumen.')
                  }
                  onDelete={() => setDeleting(d)}
                  onExport={(kind) => void exportDoc(d, kind)}
                />
              ))}
            </div>
          </section>
        </div>
      </div>

      <Modal
        open={!!renaming}
        onClose={() => setRenaming(null)}
        title="Ganti nama dokumen"
        size="sm"
        footer={
          <>
            <button type="button" className="btn btn-subtle" onClick={() => setRenaming(null)}>Batal</button>
            <button type="button" className="btn btn-primary" onClick={() => void submitRename()}>Simpan</button>
          </>
        }
      >
        <label className="label" htmlFor="rename">Judul</label>
        <input
          id="rename"
          className="input"
          autoFocus
          value={renameValue}
          onChange={(e) => setRenameValue(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && void submitRename()}
        />
      </Modal>

      <Modal
        open={!!deleting}
        onClose={() => setDeleting(null)}
        title="Hapus dokumen?"
        size="sm"
        footer={
          <>
            <button type="button" className="btn btn-subtle" onClick={() => setDeleting(null)}>Batal</button>
            <button type="button" className="btn btn-danger" onClick={() => void confirmDelete()}>Hapus</button>
          </>
        }
      >
        <p className="text-sm">
          “{deleting?.title}” akan dihapus permanen dari perangkat ini. Tindakan ini tidak dapat dibatalkan.
        </p>
      </Modal>
    </>
  )
}
