import type { DocumentRecord } from '../src/types'
import { TEMPLATES } from '../src/templates'
import { defaultDocSettings } from '../src/services/settings'

export function makeRecord(templateId = 'laporan', over: Partial<DocumentRecord> = {}): DocumentRecord {
  const tpl = TEMPLATES.find((x) => x.id === templateId)!
  return {
    id: 'test',
    title: tpl.title,
    category: tpl.category,
    content: tpl.build(),
    settings: { ...defaultDocSettings(), ...tpl.settings },
    createdAt: 0,
    updatedAt: 0,
    ...over,
  }
}
