import { Extension } from '@tiptap/core'
import { NATURAL_LINE } from '../../utils/constants'

declare module '@tiptap/core' {
  interface Commands<ReturnType> {
    paragraphStyle: {
      setLineHeight: (value: number) => ReturnType
      unsetLineHeight: () => ReturnType
      indentBlock: () => ReturnType
      outdentBlock: () => ReturnType
    }
  }
}

const BLOCKS = ['paragraph', 'heading']
const MAX_INDENT = 8

/** Spasi baris dan indentasi paragraf (atribut global pada paragraph & heading). */
export const ParagraphStyle = Extension.create({
  name: 'paragraphStyle',

  addGlobalAttributes() {
    return [
      {
        types: BLOCKS,
        attributes: {
          lineHeight: {
            default: null,
            parseHTML: (el: HTMLElement) => el.getAttribute('data-line-height'),
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            renderHTML: (a: Record<string, any>) =>
              a.lineHeight
                ? {
                    'data-line-height': String(a.lineHeight),
                    style: `line-height: ${(Number(a.lineHeight) * NATURAL_LINE).toFixed(3)}`,
                  }
                : {},
          },
          indent: {
            default: 0,
            parseHTML: (el: HTMLElement) => Number(el.getAttribute('data-indent')) || 0,
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            renderHTML: (a: Record<string, any>) =>
              a.indent ? { 'data-indent': String(a.indent), style: `margin-left: ${a.indent * 36}pt` } : {},
          },
        },
      },
    ]
  },

  addCommands() {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const update = (fn: (attrs: Record<string, any>) => Record<string, any> | null) =>
      ({ tr, state, dispatch }: { tr: import('@tiptap/pm/state').Transaction; state: import('@tiptap/pm/state').EditorState; dispatch?: (tr: import('@tiptap/pm/state').Transaction) => void }) => {
        let changed = false
        state.doc.nodesBetween(state.selection.from, state.selection.to, (node, pos) => {
          if (!BLOCKS.includes(node.type.name)) return true
          const next = fn(node.attrs)
          if (next) {
            if (dispatch) tr.setNodeMarkup(pos, undefined, { ...node.attrs, ...next })
            changed = true
          }
          return false
        })
        return changed
      }

    return {
      setLineHeight: (value: number) => update(() => ({ lineHeight: value })),
      unsetLineHeight: () => update(() => ({ lineHeight: null })),
      indentBlock: () => update((a) => ((a.indent || 0) < MAX_INDENT ? { indent: (a.indent || 0) + 1 } : null)),
      outdentBlock: () => update((a) => ((a.indent || 0) > 0 ? { indent: (a.indent || 0) - 1 } : null)),
    }
  },
})
