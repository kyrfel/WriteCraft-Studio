import { useEffect } from 'react'
import { AppShell } from './components/layout/AppShell'
import { ToastProvider } from './components/ui/Toast'
import { useHashRoute } from './hooks/useHashRoute'
import { useThemeEffect } from './hooks/useTheme'
import { DashboardPage } from './pages/DashboardPage'
import { EditorPage } from './pages/EditorPage'
import { SettingsPage } from './pages/SettingsPage'
import { requestPersistence } from './services/storage'

export default function App() {
  useThemeEffect()
  const route = useHashRoute()

  useEffect(() => {
    void requestPersistence()
  }, [])

  return (
    <ToastProvider>
      <AppShell route={route}>
        {route.name === 'dashboard' && <DashboardPage />}
        {route.name === 'editor' && <EditorPage id={route.id} />}
        {route.name === 'settings' && <SettingsPage />}
      </AppShell>
    </ToastProvider>
  )
}
