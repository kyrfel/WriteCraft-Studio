import { useRef, useState, type ReactNode } from 'react'
import type { Editor } from '@tiptap/core'
import {
  AlignCenter, AlignJustify, AlignLeft, AlignRight, ArrowUpDown, Baseline, Bold, CalendarDays, Check,
  ClipboardPaste, Copy, Eraser, Highlighter, ImageIcon, IndentDecrease, IndentIncrease, Italic, Link2, List,
  ListOrdered, Minus, Omega, Redo2, Scissors, Search, SeparatorHorizontal, Strikethrough, Subscript,
  Superscript, TableIcon, TextSelect, Underline as UnderlineIcon, Undo2,
} from 'lucide-react'
import { Dropdown } from '../components/ui/Dropdown'
import { Modal } from '../components/ui/Modal'
import { useToast } from '../components/ui/Toast'
import { useEditorTick } from '../hooks/useEditorTick'
import type { DocSettings } from '../types'
import {
  COLOR_SWATCHES, FONT_FAMILIES, FONT_SIZES, HIGHLIGHT_SWATCHES, LINE_HEIGHTS, SPECIAL_CHARS, stackFor,
} from '../utils/constants'
import { firstFamily } from '../utils/doc'
import { insertImageFiles } from './insertImage'

interface ToolbarProps {
  editor: Editor
  docSettings: DocSettings
  contentWidthPx: number
  onFind: () => void
}

function Btn({
  label, onClick, active, disabled, children,
}: { label: string; onClick: () => void; active?: boolean; disabled?: boolean; children: ReactNode }) {
  return (
    <button
      type="button"
      className="tb-btn"
      title={label}
      aria-label={label}
      aria-pressed={active}
      data-active={active ? 'true' : undefined}
      disabled={disabled}
      onMouseDown={(e) => e.preventDefault()}
      onClick={onClick}
    >
      {children}
    </button>
  )
}

const Sep = () => <span className="tb-sep" aria-hidden="true" />

const DANGEROUS = /^\s*(javascript|data|vbscript):/i

export function Toolbar({ editor, docSettings, contentWidthPx, onFind }: ToolbarProps) {
  useEditorTick(editor)
  const toast = useToast()
  const imageInput = useRef<HTMLInputElement>(null)
  const [linkOpen, setLinkOpen] = useState(false)
  const [linkUrl, setLinkUrl] = useState('')
  const [linkText, setLinkText] = useState('')
  const [linkError, setLinkError] = useState('')
  const [tableOpen, setTableOpen] = useState(false)
  const [rows, setRows] = useState(3)
  const [cols, setCols] = useState(3)
  const [headerRow, setHeaderRow] = useState(true)

  const c = () => editor.chain().focus()
  const is = (name: string, attrs?: Record<string, unknown>) => editor.isActive(name, attrs)

  const textStyle = editor.getAttributes('textStyle') as { color?: string; fontFamily?: string; fontSize?: string }
  const headingValue = is('heading', { level: 1 }) ? '1' : is('heading', { level: 2 }) ? '2' : is('heading', { level: 3 }) ? '3' : 'p'
  const currentFont = firstFamily(textStyle.fontFamily ?? docSettings.fontFamily)
  const fontKnown = FONT_FAMILIES.some((f) => f.name === currentFont)
  const currentSize = parseFloat(textStyle.fontSize ?? '') || docSettings.fontSize
  const sizes = FONT_SIZES.includes(currentSize) ? FONT_SIZES : [...FONT_SIZES, currentSize].sort((a, b) => a - b)
  const para = (editor.getAttributes('paragraph').lineHeight ?? editor.getAttributes('heading').lineHeight) as number | null | undefined
  const currentLh = Number(para) || docSettings.lineHeight
  const highlightColor = (editor.getAttributes('highlight').color as string | undefined) ?? ''

  const indent = () => (is('listItem') ? c().sinkListItem('listItem').run() : c().indentBlock().run())
  const outdent = () => (is('listItem') ? c().liftListItem('listItem').run() : c().outdentBlock().run())

  const openLink = () => {
    setLinkUrl((editor.getAttributes('link').href as string | undefined) ?? '')
    setLinkText('')
    setLinkError('')
    setLinkOpen(true)
  }
  const applyLink = () => {
    let url = linkUrl.trim()
    if (!url) {
      c().extendMarkRange('link').unsetLink().run()
      setLinkOpen(false)
      return
    }
    if (DANGEROUS.test(url)) {
      setLinkError('Jenis tautan ini tidak diizinkan. Gunakan alamat http(s), mailto, atau tel.')
      return
    }
    if (!/^([a-z][a-z0-9+.-]*:|#|\/)/i.test(url)) url = `https://${url}`
    if (editor.state.selection.empty && !is('link')) {
      c().insertContent({ type: 'text', text: linkText.trim() || url, marks: [{ type: 'link', attrs: { href: url } }] }).run()
    } else {
      c().extendMarkRange('link').setLink({ href: url }).run()
    }
    setLinkOpen(false)
  }

  const applyTable = () => {
    c().insertTable({ rows: Math.min(30, Math.max(1, rows)), cols: Math.min(10, Math.max(1, cols)), withHeaderRow: headerRow }).run()
    setTableOpen(false)
  }

  const pickImage = async (files: FileList | null) => {
    const list = Array.from(files ?? []).filter((f) => f.type.startsWith('image/'))
    if (!list.length) return
    try {
      await insertImageFiles(editor, list, contentWidthPx)
    } catch {
      toast('Gambar tidak dapat dimuat. Coba berkas PNG atau JPEG.', 'error')
    }
  }

  const copyOrCut = (cut: boolean) => {
    const { from, to } = editor.state.selection
    if (from === to) return
    editor.view.focus()
    const ok = document.execCommand(cut ? 'cut' : 'copy')
    if (!ok) {
      void navigator.clipboard?.writeText(editor.state.doc.textBetween(from, to, '\n'))
      if (cut) editor.chain().focus().deleteSelection().run()
    }
  }
  const paste = async () => {
    try {
      const text = await navigator.clipboard.readText()
      const lines = text.split(/\r?\n/)
      c().insertContent(lines.map((line) => ({ type: 'paragraph', content: line ? [{ type: 'text', text: line }] : undefined }))).run()
    } catch {
      toast('Browser memblokir akses clipboard. Gunakan Ctrl+V (⌘V di Mac).', 'error')
    }
  }

  const swatchGrid = (colors: string[], onPick: (hex: string) => void, close: () => void) => (
    <div className="grid grid-cols-5 gap-1.5 p-1">
      {colors.map((hex) => (
        <button
          key={hex}
          type="button"
          aria-label={hex}
          title={hex}
          className="h-7 w-7 rounded-md border border-black/15"
          style={{ background: hex }}
          onMouseDown={(e) => e.preventDefault()}
          onClick={() => {
            onPick(hex)
            close()
          }}
        />
      ))}
    </div>
  )

  return (
    <div
      className="no-scrollbar flex items-center gap-0.5 overflow-x-auto border-b border-line bg-surface px-2 py-1.5 md:flex-wrap md:overflow-visible"
      role="toolbar"
      aria-label="Format dokumen"
    >
      <Btn label="Urungkan (Ctrl+Z)" disabled={!editor.can().undo()} onClick={() => c().undo().run()}><Undo2 size={16} /></Btn>
      <Btn label="Ulangi (Ctrl+Y)" disabled={!editor.can().redo()} onClick={() => c().redo().run()}><Redo2 size={16} /></Btn>
      <Sep />

      <select
        className="tb-select w-[8.5rem]"
        aria-label="Gaya paragraf"
        value={headingValue}
        onChange={(e) => (e.target.value === 'p' ? c().setParagraph().run() : c().setHeading({ level: Number(e.target.value) as 1 | 2 | 3 }).run())}
      >
        <option value="p">Teks biasa</option>
        <option value="1">Judul 1</option>
        <option value="2">Judul 2</option>
        <option value="3">Judul 3</option>
      </select>
      <select
        className="tb-select w-[8.5rem]"
        aria-label="Font"
        value={fontKnown ? currentFont : ''}
        onChange={(e) => c().setFontFamily(stackFor(e.target.value)).run()}
      >
        {!fontKnown && <option value="">{currentFont}</option>}
        {FONT_FAMILIES.map((f) => <option key={f.name} value={f.name}>{f.name}</option>)}
      </select>
      <select
        className="tb-select w-16"
        aria-label="Ukuran font (pt)"
        value={currentSize}
        onChange={(e) => c().setFontSize(`${e.target.value}pt`).run()}
      >
        {sizes.map((n) => <option key={n} value={n}>{n}</option>)}
      </select>
      <Sep />

      <Btn label="Tebal (Ctrl+B)" active={is('bold')} onClick={() => c().toggleBold().run()}><Bold size={16} /></Btn>
      <Btn label="Miring (Ctrl+I)" active={is('italic')} onClick={() => c().toggleItalic().run()}><Italic size={16} /></Btn>
      <Btn label="Garis bawah (Ctrl+U)" active={is('underline')} onClick={() => c().toggleUnderline().run()}><UnderlineIcon size={16} /></Btn>
      <Btn label="Coret" active={is('strike')} onClick={() => c().toggleStrike().run()}><Strikethrough size={16} /></Btn>
      <Btn label="Subskrip" active={is('subscript')} onClick={() => c().toggleSubscript().run()}><Subscript size={16} /></Btn>
      <Btn label="Superskrip" active={is('superscript')} onClick={() => c().toggleSuperscript().run()}><Superscript size={16} /></Btn>

      <Dropdown label="Warna teks" trigger={<span className="flex flex-col items-center"><Baseline size={16} /><span className="mt-px h-[3px] w-4 rounded-full" style={{ background: textStyle.color ?? 'currentColor' }} /></span>}>
        {(close) => (
          <div className="w-44">
            {swatchGrid(COLOR_SWATCHES, (hex) => c().setColor(hex).run(), close)}
            <label className="menu-item mt-1 cursor-pointer">
              Warna lain…
              <input type="color" className="ml-auto h-6 w-8 cursor-pointer border-0 bg-transparent p-0" onChange={(e) => c().setColor(e.target.value).run()} />
            </label>
            <button type="button" className="menu-item" onMouseDown={(e) => e.preventDefault()} onClick={() => { c().unsetColor().run(); close() }}>Warna bawaan</button>
          </div>
        )}
      </Dropdown>
      <Dropdown label="Sorot teks" active={is('highlight')} trigger={<span className="flex flex-col items-center"><Highlighter size={16} /><span className="mt-px h-[3px] w-4 rounded-full" style={{ background: highlightColor || 'transparent' }} /></span>}>
        {(close) => (
          <div className="w-44">
            {swatchGrid(HIGHLIGHT_SWATCHES, (hex) => c().setHighlight({ color: hex }).run(), close)}
            <button type="button" className="menu-item mt-1" onMouseDown={(e) => e.preventDefault()} onClick={() => { c().unsetHighlight().run(); close() }}>Hapus sorotan</button>
          </div>
        )}
      </Dropdown>
      <Btn label="Hapus format teks" onClick={() => c().unsetAllMarks().run()}><Eraser size={16} /></Btn>
      <Sep />

      <Btn label="Rata kiri" active={is('paragraph', { textAlign: 'left' }) || is('heading', { textAlign: 'left' })} onClick={() => c().setTextAlign('left').run()}><AlignLeft size={16} /></Btn>
      <Btn label="Rata tengah" active={editor.isActive({ textAlign: 'center' })} onClick={() => c().setTextAlign('center').run()}><AlignCenter size={16} /></Btn>
      <Btn label="Rata kanan" active={editor.isActive({ textAlign: 'right' })} onClick={() => c().setTextAlign('right').run()}><AlignRight size={16} /></Btn>
      <Btn label="Rata kiri-kanan" active={editor.isActive({ textAlign: 'justify' })} onClick={() => c().setTextAlign('justify').run()}><AlignJustify size={16} /></Btn>
      <Dropdown label="Spasi baris" trigger={<ArrowUpDown size={16} />}>
        {(close) => (
          <div className="w-36">
            {LINE_HEIGHTS.map((n) => (
              <button
                key={n}
                type="button"
                className="menu-item"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => { c().setLineHeight(n).run(); close() }}
              >
                <Check size={14} className={n === currentLh ? '' : 'invisible'} /> {n.toLocaleString('id-ID', { minimumFractionDigits: 1 })}
              </button>
            ))}
          </div>
        )}
      </Dropdown>
      <Sep />

      <Btn label="Daftar poin" active={is('bulletList')} onClick={() => c().toggleBulletList().run()}><List size={16} /></Btn>
      <Btn label="Daftar bernomor" active={is('orderedList')} onClick={() => c().toggleOrderedList().run()}><ListOrdered size={16} /></Btn>
      <Btn label="Kurangi indentasi" onClick={outdent}><IndentDecrease size={16} /></Btn>
      <Btn label="Tambah indentasi" onClick={indent}><IndentIncrease size={16} /></Btn>
      <Sep />

      <Btn label="Sisipkan tautan" active={is('link')} onClick={openLink}><Link2 size={16} /></Btn>
      <Btn label="Sisipkan gambar" onClick={() => imageInput.current?.click()}><ImageIcon size={16} /></Btn>
      <input
        ref={imageInput}
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        onChange={(e) => {
          void pickImage(e.target.files)
          e.target.value = ''
        }}
      />
      <Btn label="Sisipkan tabel" onClick={() => setTableOpen(true)}><TableIcon size={16} /></Btn>
      <Btn label="Garis horizontal" onClick={() => c().setHorizontalRule().run()}><Minus size={16} /></Btn>
      <Btn label="Pemisah halaman" onClick={() => c().insertPageBreak().run()}><SeparatorHorizontal size={16} /></Btn>
      <Btn label="Sisipkan tanggal hari ini" onClick={() => c().insertContent(new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })).run()}><CalendarDays size={16} /></Btn>
      <Dropdown label="Karakter khusus" trigger={<Omega size={16} />}>
        {(close) => (
          <div className="grid w-60 grid-cols-8 gap-0.5">
            {SPECIAL_CHARS.map((ch) => (
              <button
                key={ch}
                type="button"
                className="h-8 rounded-md text-base hover:bg-surface2"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => { c().insertContent(ch).run(); close() }}
              >
                {ch}
              </button>
            ))}
          </div>
        )}
      </Dropdown>
      <Sep />

      <Btn label="Salin (Ctrl+C)" onClick={() => copyOrCut(false)}><Copy size={16} /></Btn>
      <Btn label="Potong (Ctrl+X)" onClick={() => copyOrCut(true)}><Scissors size={16} /></Btn>
      <Btn label="Tempel (Ctrl+V)" onClick={() => void paste()}><ClipboardPaste size={16} /></Btn>
      <Btn label="Pilih semua (Ctrl+A)" onClick={() => c().selectAll().run()}><TextSelect size={16} /></Btn>
      <Btn label="Cari dan ganti (Ctrl+F)" onClick={onFind}><Search size={16} /></Btn>

      {is('table') && (
        <>
          <Sep />
          <Dropdown label="Alat tabel" className="tb-btn px-2 text-sm font-medium" active trigger={<span>Tabel ▾</span>}>
            {(close) => {
              const item = (label: string, run: () => void, danger = false) => (
                <button key={label} type="button" className={`menu-item ${danger ? 'text-red-600' : ''}`} onMouseDown={(e) => e.preventDefault()} onClick={() => { run(); close() }}>
                  {label}
                </button>
              )
              return (
                <div className="w-48">
                  {item('Tambah baris di atas', () => c().addRowBefore().run())}
                  {item('Tambah baris di bawah', () => c().addRowAfter().run())}
                  {item('Tambah kolom di kiri', () => c().addColumnBefore().run())}
                  {item('Tambah kolom di kanan', () => c().addColumnAfter().run())}
                  <div className="my-1 h-px bg-line" />
                  {item('Jadikan baris header', () => c().toggleHeaderRow().run())}
                  {item('Gabungkan sel', () => c().mergeCells().run())}
                  {item('Pisahkan sel', () => c().splitCell().run())}
                  <div className="my-1 h-px bg-line" />
                  {item('Hapus baris', () => c().deleteRow().run(), true)}
                  {item('Hapus kolom', () => c().deleteColumn().run(), true)}
                  {item('Hapus tabel', () => c().deleteTable().run(), true)}
                </div>
              )
            }}
          </Dropdown>
        </>
      )}

      {is('image') && (
        <>
          <Sep />
          {[25, 50, 75, 100].map((pct) => (
            <button
              key={pct}
              type="button"
              className="tb-btn px-2 text-xs"
              title={`Lebar gambar ${pct}%`}
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => c().updateAttributes('image', { width: Math.round((contentWidthPx * pct) / 100) }).run()}
            >
              {pct}%
            </button>
          ))}
          <Btn label="Gambar rata kiri" onClick={() => c().updateAttributes('image', { align: 'left' }).run()}><AlignLeft size={16} /></Btn>
          <Btn label="Gambar di tengah" onClick={() => c().updateAttributes('image', { align: 'center' }).run()}><AlignCenter size={16} /></Btn>
          <Btn label="Gambar rata kanan" onClick={() => c().updateAttributes('image', { align: 'right' }).run()}><AlignRight size={16} /></Btn>
        </>
      )}

      <Modal
        open={linkOpen}
        onClose={() => setLinkOpen(false)}
        title="Sisipkan tautan"
        size="sm"
        footer={
          <>
            <button type="button" className="btn btn-subtle" onClick={() => setLinkOpen(false)}>Batal</button>
            <button type="button" className="btn btn-primary" onClick={applyLink}>{linkUrl.trim() ? 'Terapkan' : 'Hapus tautan'}</button>
          </>
        }
      >
        <label className="label" htmlFor="link-url">Alamat (URL)</label>
        <input
          id="link-url"
          className="input"
          autoFocus
          placeholder="https://contoh.id"
          value={linkUrl}
          onChange={(e) => { setLinkUrl(e.target.value); setLinkError('') }}
          onKeyDown={(e) => e.key === 'Enter' && applyLink()}
        />
        {editor.state.selection.empty && !is('link') && (
          <>
            <label className="label mt-3" htmlFor="link-text">Teks tautan (opsional)</label>
            <input id="link-text" className="input" value={linkText} onChange={(e) => setLinkText(e.target.value)} />
          </>
        )}
        {linkError && <p className="mt-2 text-sm text-red-600">{linkError}</p>}
      </Modal>

      <Modal
        open={tableOpen}
        onClose={() => setTableOpen(false)}
        title="Sisipkan tabel"
        size="sm"
        footer={
          <>
            <button type="button" className="btn btn-subtle" onClick={() => setTableOpen(false)}>Batal</button>
            <button type="button" className="btn btn-primary" onClick={applyTable}>Sisipkan</button>
          </>
        }
      >
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label" htmlFor="t-rows">Baris</label>
            <input id="t-rows" type="number" min={1} max={30} className="input" value={rows} onChange={(e) => setRows(Number(e.target.value) || 1)} />
          </div>
          <div>
            <label className="label" htmlFor="t-cols">Kolom</label>
            <input id="t-cols" type="number" min={1} max={10} className="input" value={cols} onChange={(e) => setCols(Number(e.target.value) || 1)} />
          </div>
        </div>
        <label className="mt-3 flex items-center gap-2 text-sm">
          <input type="checkbox" className="h-4 w-4 accent-[rgb(var(--brand))]" checked={headerRow} onChange={(e) => setHeaderRow(e.target.checked)} />
          Baris pertama sebagai header
        </label>
      </Modal>
    </div>
  )
}
