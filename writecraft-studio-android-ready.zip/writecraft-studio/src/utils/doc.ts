import type { DocNode } from '../types'

export const EMPTY_DOC: DocNode = { type: 'doc', content: [{ type: 'paragraph' }] }

const TEXT_BLOCKS = new Set(['paragraph', 'heading', 'codeBlock'])

function inlineText(n: DocNode): string {
  return (n.content ?? [])
    .map((c) => (c.type === 'text' ? c.text ?? '' : c.type === 'hardBreak' ? '\n' : ''))
    .join('')
}

function walk(n: DocNode | undefined, out: string[]): void {
  if (!n) return
  if (n.type && TEXT_BLOCKS.has(n.type)) {
    out.push(inlineText(n))
    return
  }
  ;(n.content ?? []).forEach((c) => walk(c, out))
}

/** Teks polos dari sebuah dokumen (satu baris per paragraf). */
export function docToPlainText(doc?: DocNode): string {
  const out: string[] = []
  walk(doc, out)
  return out.join('\n')
}

export function previewText(doc: DocNode | undefined, max = 140): string {
  const t = docToPlainText(doc).replace(/\s+/g, ' ').trim()
  return t.length > max ? `${t.slice(0, max).trimEnd()}…` : t
}

/** Nama keluarga font pertama dari string font-family CSS. */
export function firstFamily(font: string): string {
  return font.split(',')[0].replace(/["']/g, '').trim()
}

/** Kumpulkan semua src gambar di dalam dokumen. */
export function collectImageSrcs(node: DocNode | undefined, acc: Set<string> = new Set()): Set<string> {
  if (!node) return acc
  if (node.type === 'image' && typeof node.attrs?.src === 'string') acc.add(node.attrs.src)
  node.content?.forEach((c) => collectImageSrcs(c, acc))
  return acc
}
