import { jsPDF } from 'jspdf'
import type { DocNode, DocumentRecord } from '../types'
import { hexToRgb, toHex } from '../utils/color'
import { collectImageSrcs, firstFamily } from '../utils/doc'
import { NATURAL_LINE } from '../utils/constants'
import { CM_TO_PT, getPageDims } from '../utils/page'
import { tableGrid } from '../utils/tableGrid'
import { rasterizeAll, type ImageMap } from './imageUtils'

type Family = 'helvetica' | 'times' | 'courier'
type RGB = [number, number, number]

interface Style {
  family: Family
  bold: boolean
  italic: boolean
  size: number
  color: RGB
  underline: boolean
  strike: boolean
  highlight: RGB | null
  link: string | null
}
interface Token {
  text: string
  w: number
  style: Style
  space: boolean
  br: boolean
}
interface Line {
  tokens: Token[]
  width: number
  /** true bila baris berakhir karena paragraf/hard-break (bukan karena pembungkusan). */
  hardEnd: boolean
}
interface Ctx {
  base: Style
  cell: boolean
}
interface InlineOpts {
  x: number
  width: number
  align: string
  lh: number
  base: Style
  before: number
  after: number
  pre?: boolean
  marker?: (baseline: number, size: number) => void
}

const PX_TO_PT = 0.75
const HEADING_SIZE: Record<number, number> = { 1: 24, 2: 18, 3: 14 }
const LIST_INDENT = 27

/** jsPDF memakai font standar (WinAnsi); karakter di luar itu diganti '?'. */
export function sanitize(s: string): string {
  return s
    .replace(/[\u00a0\u2007\u202f]/g, ' ')
    .replace(/[\u200b-\u200d\ufeff]/g, '')
    .replace(/[^\u0000-\u00ff\u2018\u2019\u201c\u201d\u2013\u2014\u2022\u2026\u20ac\u2122\u2020\u2021\u2030]/g, '?')
}

function mapFamily(font: string): Family {
  const n = firstFamily(font).toLowerCase()
  if (/courier|mono|consolas/.test(n)) return 'courier'
  if (/times|georgia|garamond|cambria|palatino|^serif$/.test(n)) return 'times'
  return 'helvetica'
}

function fontStyle(s: Style): string {
  if (s.bold && s.italic) return 'bolditalic'
  if (s.bold) return 'bold'
  if (s.italic) return 'italic'
  return 'normal'
}

function toAlpha(n: number): string {
  return String.fromCharCode(97 + ((n - 1) % 26))
}
function toRoman(n: number): string {
  const map: [number, string][] = [[10, 'x'], [9, 'ix'], [5, 'v'], [4, 'iv'], [1, 'i']]
  let out = ''
  let rest = n
  for (const [v, s] of map) {
    while (rest >= v) {
      out += s
      rest -= v
    }
  }
  return out
}
export function formatListNumber(n: number, level: number): string {
  const k = level % 3
  if (k === 0) return `${n}.`
  if (k === 1) return `${toAlpha(n)}.`
  return `${toRoman(n)}.`
}

function inlineText(n: DocNode): string {
  return (n.content ?? []).map((c) => c.text ?? '').join('')
}

class PdfBuilder {
  readonly doc: jsPDF
  private pageW: number
  private pageH: number
  private mL: number
  private mR: number
  private mT: number
  private mB: number
  private contentW: number
  private y: number
  private dry = false

  constructor(private record: DocumentRecord, private images: ImageMap) {
    const s = record.settings
    const dims = getPageDims(s)
    this.pageW = dims.width * CM_TO_PT
    this.pageH = dims.height * CM_TO_PT
    this.mL = s.margins.left * CM_TO_PT
    this.mR = s.margins.right * CM_TO_PT
    this.mT = s.margins.top * CM_TO_PT
    this.mB = s.margins.bottom * CM_TO_PT
    this.contentW = this.pageW - this.mL - this.mR
    this.y = this.mT
    this.doc = new jsPDF({
      unit: 'pt',
      format: [this.pageW, this.pageH],
      orientation: s.orientation === 'landscape' ? 'landscape' : 'portrait',
      compress: true,
    })
  }

  build(): jsPDF {
    const ctx: Ctx = { base: this.baseStyle(), cell: false }
    this.renderBlocks(this.record.content.content ?? [], this.mL, this.contentW, ctx)
    this.decoratePages()
    this.doc.setProperties({ title: this.record.title, creator: 'WriteCraft Studio' })
    return this.doc
  }

  // ---------- gaya & pengukuran ----------

  private baseStyle(): Style {
    const s = this.record.settings
    return {
      family: mapFamily(s.fontFamily),
      bold: false,
      italic: false,
      size: s.fontSize,
      color: [0, 0, 0],
      underline: false,
      strike: false,
      highlight: null,
      link: null,
    }
  }

  private styleFromMarks(marks: DocNode['marks'] = [], base: Style): Style {
    const s: Style = { ...base }
    for (const m of marks) {
      switch (m.type) {
        case 'bold':
          s.bold = true
          break
        case 'italic':
          s.italic = true
          break
        case 'underline':
          s.underline = true
          break
        case 'strike':
          s.strike = true
          break
        case 'code':
          s.family = 'courier'
          break
        case 'highlight': {
          const hex = toHex(m.attrs?.color) ?? 'FFFF00'
          s.highlight = hexToRgb(hex)
          break
        }
        case 'link':
          s.link = String(m.attrs?.href ?? '') || null
          s.color = [5, 99, 193]
          s.underline = true
          break
        case 'textStyle': {
          const a = m.attrs ?? {}
          const hex = toHex(a.color)
          if (hex && !s.link) s.color = hexToRgb(hex)
          if (a.fontFamily) s.family = mapFamily(String(a.fontFamily))
          if (a.fontSize) {
            const pt = parseFloat(String(a.fontSize))
            if (pt > 0) s.size = pt
          }
          break
        }
      }
    }
    return s
  }

  private applyFont(s: Style): void {
    this.doc.setFont(s.family, fontStyle(s))
    this.doc.setFontSize(s.size)
  }

  private measure(text: string, s: Style): number {
    this.applyFont(s)
    return this.doc.getTextWidth(text)
  }

  // ---------- tokenisasi & pemotongan baris ----------

  private tokenize(nodes: DocNode[], base: Style, pre = false): Token[] {
    const tokens: Token[] = []
    for (const n of nodes) {
      if (n.type === 'text') {
        const style = this.styleFromMarks(n.marks, base)
        const parts = (n.text ?? '').split(/(\s+)/).filter((p) => p !== '')
        for (const part of parts) {
          const isSpace = /^\s+$/.test(part)
          if (isSpace && !pre) {
            tokens.push({ text: ' ', w: this.measure(' ', style), style, space: true, br: false })
          } else {
            const text = sanitize(isSpace ? part.replace(/\t/g, '    ') : part)
            tokens.push({ text, w: this.measure(text, style), style, space: false, br: false })
          }
        }
      } else if (n.type === 'hardBreak') {
        tokens.push({ text: '', w: 0, style: base, space: false, br: true })
      }
    }
    return tokens
  }

  private splitWord(t: Token, width: number): Token[] {
    const pieces: Token[] = []
    let buf = ''
    for (const ch of t.text) {
      if (buf && this.measure(buf + ch, t.style) > width) {
        pieces.push({ ...t, text: buf, w: this.measure(buf, t.style) })
        buf = ch
      } else {
        buf += ch
      }
    }
    if (buf) pieces.push({ ...t, text: buf, w: this.measure(buf, t.style) })
    return pieces
  }

  private breakLines(tokens: Token[], width: number): Line[] {
    const lines: Line[] = []
    let cur: Token[] = []
    let curW = 0
    const flush = (hard: boolean) => {
      while (cur.length && cur[cur.length - 1].space) curW -= cur.pop()!.w
      lines.push({ tokens: cur, width: curW, hardEnd: hard })
      cur = []
      curW = 0
    }
    for (const t of tokens) {
      if (t.br) {
        flush(true)
        continue
      }
      if (t.space && cur.length === 0) continue
      const pieces = !t.space && t.w > width ? this.splitWord(t, width) : [t]
      for (const p of pieces) {
        if (cur.length > 0 && !p.space && curW + p.w > width + 0.01) flush(false)
        cur.push(p)
        curW += p.w
      }
    }
    flush(true)
    return lines
  }

  // ---------- halaman ----------

  private newPage(): void {
    this.doc.addPage()
    this.y = this.mT
  }

  private ensureSpace(h: number): void {
    if (!this.dry && this.y + h > this.pageH - this.mB + 0.01) this.newPage()
  }

  private pageNumber(): number {
    return this.doc.getNumberOfPages()
  }

  // ---------- teks ----------

  private renderInline(nodes: DocNode[] | undefined, o: InlineOpts): void {
    const tokens = this.tokenize(nodes ?? [], o.base, o.pre)
    const lines = this.breakLines(tokens, o.width)
    if (o.before && this.y > this.mT + 0.5) this.y += o.before
    lines.forEach((line, i) => {
      const size = line.tokens.reduce((m, t) => Math.max(m, t.style.size), o.base.size)
      const lineH = size * NATURAL_LINE * o.lh
      this.ensureSpace(lineH)
      const baseline = this.y + (lineH - size * NATURAL_LINE) / 2 + size * 0.95
      if (!this.dry) {
        if (i === 0 && o.marker) o.marker(baseline, size)
        this.drawLine(line, o.x, o.width, baseline, o.align)
      }
      this.y += lineH
    })
    this.y += o.after
  }

  private drawLine(line: Line, x: number, width: number, baseline: number, align: string): void {
    let cx = x
    let extra = 0
    if (align === 'center') cx = x + (width - line.width) / 2
    else if (align === 'right') cx = x + width - line.width
    else if (align === 'justify' && !line.hardEnd) {
      const spaces = line.tokens.filter((t) => t.space).length
      if (spaces > 0) extra = (width - line.width) / spaces
    }
    for (const t of line.tokens) {
      const w = t.w + (t.space ? extra : 0)
      this.drawToken(t, cx, baseline, w)
      cx += w
    }
  }

  private drawToken(t: Token, cx: number, baseline: number, w: number): void {
    const s = t.style
    const d = this.doc
    if (s.highlight) {
      d.setFillColor(s.highlight[0], s.highlight[1], s.highlight[2])
      d.rect(cx, baseline - s.size * 0.85, w, s.size * 1.15, 'F')
    }
    if (!t.space && t.text) {
      this.applyFont(s)
      d.setTextColor(s.color[0], s.color[1], s.color[2])
      d.text(t.text, cx, baseline)
    }
    if (s.underline || s.strike) {
      d.setDrawColor(s.color[0], s.color[1], s.color[2])
      d.setLineWidth(Math.max(0.5, s.size / 18))
      if (s.underline) d.line(cx, baseline + s.size * 0.12, cx + w, baseline + s.size * 0.12)
      if (s.strike) d.line(cx, baseline - s.size * 0.3, cx + w, baseline - s.size * 0.3)
    }
    if (s.link && !t.space) {
      d.link(cx, baseline - s.size * 0.85, w, s.size * 1.1, { url: s.link })
    }
  }

  // ---------- blok ----------

  private renderBlocks(nodes: DocNode[], x: number, width: number, ctx: Ctx): void {
    for (const n of nodes) this.renderBlock(n, x, width, ctx)
  }

  private renderBlock(n: DocNode, x: number, width: number, ctx: Ctx): void {
    const s = this.record.settings
    switch (n.type) {
      case 'paragraph': {
        const a = n.attrs ?? {}
        const indent = (Number(a.indent) || 0) * 36
        this.renderInline(n.content, {
          x: x + indent,
          width: width - indent,
          align: String(a.textAlign ?? 'left'),
          lh: Number(a.lineHeight) || s.lineHeight,
          base: ctx.base,
          before: 0,
          after: ctx.cell ? 0 : 6,
        })
        break
      }
      case 'heading': {
        const a = n.attrs ?? {}
        const level = Math.min(3, Math.max(1, Number(a.level) || 1))
        this.renderInline(n.content, {
          x,
          width,
          align: String(a.textAlign ?? 'left'),
          lh: Number(a.lineHeight) || s.lineHeight,
          base: { ...ctx.base, bold: true, size: HEADING_SIZE[level] },
          before: ctx.cell ? 0 : 12,
          after: ctx.cell ? 0 : 6,
        })
        break
      }
      case 'bulletList':
        this.renderList(n, x, width, 0, false, ctx)
        break
      case 'orderedList':
        this.renderList(n, x, width, 0, true, ctx)
        break
      case 'blockquote': {
        const startY = this.y
        const startPage = this.pageNumber()
        const q: Ctx = { ...ctx, base: { ...ctx.base, italic: true, color: [85, 85, 85] } }
        this.renderBlocks(n.content ?? [], x + 18, width - 18, q)
        if (!this.dry && this.pageNumber() === startPage) {
          this.doc.setDrawColor(170, 170, 170)
          this.doc.setLineWidth(2)
          this.doc.line(x + 6, startY, x + 6, this.y - 2)
        }
        break
      }
      case 'codeBlock': {
        const base: Style = { ...ctx.base, family: 'courier', size: 10, highlight: [243, 244, 246] }
        for (const line of inlineText(n).split('\n')) {
          this.renderInline([{ type: 'text', text: line }], {
            x, width, align: 'left', lh: 1.05, base, before: 0, after: 0, pre: true,
          })
        }
        this.y += 6
        break
      }
      case 'horizontalRule':
        this.ensureSpace(14)
        this.y += 5
        if (!this.dry) {
          this.doc.setDrawColor(153, 153, 153)
          this.doc.setLineWidth(0.75)
          this.doc.line(x, this.y, x + width, this.y)
        }
        this.y += 9
        break
      case 'pageBreak':
        if (!this.dry) this.newPage()
        break
      case 'image':
        this.renderImage(n, x, width)
        break
      case 'table':
        this.renderTable(n, x, width, ctx)
        break
      default:
        if (n.content) this.renderBlocks(n.content, x, width, ctx)
    }
  }

  private renderList(node: DocNode, x: number, width: number, level: number, ordered: boolean, ctx: Ctx): void {
    let n = Number(node.attrs?.start) || 1
    for (const li of node.content ?? []) {
      let first = true
      for (const child of li.content ?? []) {
        if (child.type === 'paragraph') {
          const a = child.attrs ?? {}
          const label = ordered ? formatListNumber(n, level) : ''
          this.renderInline(child.content, {
            x: x + LIST_INDENT,
            width: width - LIST_INDENT,
            align: String(a.textAlign ?? 'left'),
            lh: Number(a.lineHeight) || this.record.settings.lineHeight,
            base: ctx.base,
            before: 0,
            after: 2,
            marker: first
              ? (baseline, size) => this.drawMarker(x, baseline, size, level, ordered, label, ctx.base)
              : undefined,
          })
          first = false
        } else if (child.type === 'bulletList') {
          this.renderList(child, x + LIST_INDENT, width - LIST_INDENT, level + 1, false, ctx)
        } else if (child.type === 'orderedList') {
          this.renderList(child, x + LIST_INDENT, width - LIST_INDENT, level + 1, true, ctx)
        } else {
          this.renderBlock(child, x + LIST_INDENT, width - LIST_INDENT, ctx)
        }
      }
      n++
    }
    if (level === 0) this.y += 4
  }

  private drawMarker(
    x: number, baseline: number, size: number, level: number, ordered: boolean, label: string, base: Style,
  ): void {
    const d = this.doc
    d.setTextColor(base.color[0], base.color[1], base.color[2])
    if (ordered) {
      this.applyFont({ ...base, size })
      d.text(label, x + LIST_INDENT - 6, baseline, { align: 'right' })
      return
    }
    const cx = x + LIST_INDENT - 12
    const cy = baseline - size * 0.3
    const r = size * 0.13
    d.setFillColor(base.color[0], base.color[1], base.color[2])
    d.setDrawColor(base.color[0], base.color[1], base.color[2])
    d.setLineWidth(0.6)
    if (level % 3 === 0) d.circle(cx, cy, r, 'F')
    else if (level % 3 === 1) d.circle(cx, cy, r, 'S')
    else d.rect(cx - r, cy - r, r * 2, r * 2, 'F')
  }

  private renderImage(n: DocNode, x: number, width: number): void {
    const r = this.images.get(String(n.attrs?.src ?? ''))
    if (!r) {
      this.renderInline([{ type: 'text', text: '[Gambar tidak dapat diekspor]' }], {
        x, width, align: 'left', lh: 1, before: 0, after: 6,
        base: { ...this.baseStyle(), italic: true, color: [136, 136, 136] },
      })
      return
    }
    const maxH = this.pageH - this.mT - this.mB
    let w = (Number(n.attrs?.width) || r.width) * PX_TO_PT
    w = Math.min(w, width)
    let h = (w * r.height) / r.width
    if (h > maxH) {
      w = (w * maxH) / h
      h = maxH
    }
    this.ensureSpace(h)
    if (!this.dry) {
      const align = String(n.attrs?.align ?? 'left')
      const ix = align === 'center' ? x + (width - w) / 2 : align === 'right' ? x + width - w : x
      this.doc.addImage(r.dataUrl, r.format, ix, this.y, w, h)
    }
    this.y += h + 6
  }

  // ---------- tabel ----------

  private measureBlocks(nodes: DocNode[], x: number, width: number, ctx: Ctx): number {
    const savedY = this.y
    const savedDry = this.dry
    this.dry = true
    this.y = 0
    this.renderBlocks(nodes, x, width, ctx)
    const h = this.y
    this.dry = savedDry
    this.y = savedY
    return h
  }

  private renderTable(n: DocNode, x: number, width: number, ctx: Ctx): void {
    const { cols, fractions } = tableGrid(n)
    const colW = fractions.map((f) => f * width)
    const pad = 4
    const occupied: number[] = new Array(cols).fill(0)
    const pageContentH = this.pageH - this.mT - this.mB

    for (const row of n.content ?? []) {
      type Placed = { cell: DocNode; cx: number; cw: number; h: number }
      const placed: Placed[] = []
      let col = 0
      let rowH = 0
      for (const cell of row.content ?? []) {
        while (col < cols && occupied[col] > 0) col++
        const span = Math.max(1, Math.min(Number(cell.attrs?.colspan) || 1, cols - col))
        const rowspan = Math.max(1, Number(cell.attrs?.rowspan) || 1)
        const cw = colW.slice(col, col + span).reduce((a, b) => a + b, 0)
        const cx = x + colW.slice(0, col).reduce((a, b) => a + b, 0)
        const isHeader = cell.type === 'tableHeader'
        const cellCtx: Ctx = { base: isHeader ? { ...ctx.base, bold: true } : ctx.base, cell: true }
        const h = this.measureBlocks(cell.content ?? [], cx + pad, cw - pad * 2, cellCtx) + pad * 2
        rowH = Math.max(rowH, h / rowspan)
        placed.push({ cell, cx, cw, h })
        for (let c = col; c < col + span; c++) occupied[c] = rowspan
        col += span
      }
      rowH = Math.max(rowH, ctx.base.size * NATURAL_LINE + pad * 2)
      if (rowH <= pageContentH) this.ensureSpace(rowH)
      const top = this.y
      if (!this.dry) {
        for (const p of placed) {
          const isHeader = p.cell.type === 'tableHeader'
          this.doc.setDrawColor(153, 153, 153)
          this.doc.setLineWidth(0.5)
          if (isHeader) {
            this.doc.setFillColor(241, 241, 241)
            this.doc.rect(p.cx, top, p.cw, rowH, 'FD')
          } else {
            this.doc.rect(p.cx, top, p.cw, rowH, 'S')
          }
          this.y = top + pad
          const cellCtx: Ctx = { base: isHeader ? { ...ctx.base, bold: true } : ctx.base, cell: true }
          this.renderBlocks(p.cell.content ?? [], p.cx + pad, p.cw - pad * 2, cellCtx)
        }
      }
      this.y = top + rowH
      for (let c = 0; c < cols; c++) if (occupied[c] > 0) occupied[c]--
    }
    this.y += 8
  }

  // ---------- header / footer ----------

  private decoratePages(): void {
    const s = this.record.settings
    const total = this.doc.getNumberOfPages()
    const header = sanitize(s.header.trim())
    const footer = sanitize(s.footer.trim())
    const fy = this.pageH - Math.max(18, this.mB * 0.45)
    for (let i = 1; i <= total; i++) {
      this.doc.setPage(i)
      this.doc.setFont('helvetica', 'normal')
      this.doc.setFontSize(9)
      this.doc.setTextColor(119, 119, 119)
      if (header) this.doc.text(header, this.pageW - this.mR, Math.max(20, this.mT * 0.5), { align: 'right' })
      if (footer && s.showPageNumber) {
        this.doc.text(footer, this.pageW / 2, fy - 5, { align: 'center' })
        this.doc.text(`Halaman ${i} dari ${total}`, this.pageW / 2, fy + 7, { align: 'center' })
      } else if (footer) {
        this.doc.text(footer, this.pageW / 2, fy, { align: 'center' })
      } else if (s.showPageNumber) {
        this.doc.text(`Halaman ${i} dari ${total}`, this.pageW / 2, fy, { align: 'center' })
      }
    }
  }
}

export function buildPdf(record: DocumentRecord, images: ImageMap = new Map()): jsPDF {
  return new PdfBuilder(record, images).build()
}

/** Hasilkan berkas PDF valid dari dokumen WriteCraft. */
export async function exportPdf(record: DocumentRecord): Promise<Blob> {
  const images = await rasterizeAll(collectImageSrcs(record.content))
  return buildPdf(record, images).output('blob')
}
