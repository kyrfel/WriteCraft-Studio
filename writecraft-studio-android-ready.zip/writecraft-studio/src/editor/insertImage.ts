import type { Editor } from '@tiptap/core'
import { fileToImage } from '../services/imageUtils'

/** Sisipkan file gambar ke editor (diperkecil bila terlalu besar, lebar disesuaikan dengan halaman). */
export async function insertImageFiles(editor: Editor, files: File[], maxWidthPx: number): Promise<void> {
  for (const file of files) {
    const img = await fileToImage(file)
    const width = Math.round(Math.min(img.width, Math.max(50, maxWidthPx)))
    editor.chain().focus().insertContent({ type: 'image', attrs: { src: img.src, alt: file.name, width } }).run()
  }
}
