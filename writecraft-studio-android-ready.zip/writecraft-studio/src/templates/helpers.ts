import type { DocNode } from '../types'

type Attrs = Record<string, unknown>

export const t = (text: string, marks?: DocNode['marks']): DocNode => ({
  type: 'text',
  text,
  ...(marks ? { marks } : {}),
})

export const b = (text: string): DocNode => t(text, [{ type: 'bold' }])
export const i = (text: string): DocNode => t(text, [{ type: 'italic' }])

type Inline = string | DocNode[]
const toInline = (c: Inline): DocNode[] | undefined =>
  typeof c === 'string' ? (c ? [t(c)] : undefined) : c.length ? c : undefined

export const p = (content: Inline = '', attrs?: Attrs): DocNode => ({
  type: 'paragraph',
  ...(attrs ? { attrs } : {}),
  ...(toInline(content) ? { content: toInline(content) } : {}),
})

export const h = (level: 1 | 2 | 3, content: Inline, attrs?: Attrs): DocNode => ({
  type: 'heading',
  attrs: { level, ...(attrs ?? {}) },
  ...(toInline(content) ? { content: toInline(content) } : {}),
})

const li = (c: Inline): DocNode => ({ type: 'listItem', content: [p(c)] })
export const ul = (items: Inline[]): DocNode => ({ type: 'bulletList', content: items.map(li) })
export const ol = (items: Inline[]): DocNode => ({ type: 'orderedList', attrs: { start: 1 }, content: items.map(li) })

export const hr = (): DocNode => ({ type: 'horizontalRule' })
export const pageBreak = (): DocNode => ({ type: 'pageBreak' })
export const blank = (): DocNode => p()

export const table = (headers: string[], rows: string[][]): DocNode => ({
  type: 'table',
  content: [
    {
      type: 'tableRow',
      content: headers.map((x) => ({ type: 'tableHeader', attrs: { colspan: 1, rowspan: 1, colwidth: null }, content: [p(x)] })),
    },
    ...rows.map((r) => ({
      type: 'tableRow',
      content: r.map((x) => ({ type: 'tableCell', attrs: { colspan: 1, rowspan: 1, colwidth: null }, content: [p(x)] })),
    })),
  ],
})

export const center = { textAlign: 'center' }
export const justify = { textAlign: 'justify' }
export const right = { textAlign: 'right' }
