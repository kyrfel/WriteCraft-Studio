import { useCallback, useEffect, useRef, useState } from 'react'
import { listDocuments, subscribeDocuments } from '../services/storage'
import type { DocumentRecord } from '../types'

export function useDocuments(): { docs: DocumentRecord[]; loading: boolean; error: string | null; reload: () => Promise<void> } {
  const [docs, setDocs] = useState<DocumentRecord[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const timer = useRef<number | undefined>(undefined)

  const reload = useCallback(async () => {
    try {
      setDocs(await listDocuments())
      setError(null)
    } catch {
      setError('Penyimpanan browser tidak dapat diakses. Pastikan mode privat/penyimpanan tidak diblokir.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    void reload()
    const unsubscribe = subscribeDocuments(() => {
      window.clearTimeout(timer.current)
      timer.current = window.setTimeout(() => void reload(), 300)
    })
    return () => {
      unsubscribe()
      window.clearTimeout(timer.current)
    }
  }, [reload])

  return { docs, loading, error, reload }
}
