import type { DocumentRecord } from '../types'
import { downloadBlob, safeFileName } from '../utils/format'

export type ExportKind = 'docx' | 'pdf'

/**
 * Ekspor dokumen lalu unduh. Library ekspor dimuat saat dibutuhkan (code splitting)
 * agar aplikasi cepat dibuka.
 */
export async function downloadDocument(record: DocumentRecord, kind: ExportKind): Promise<void> {
  const blob =
    kind === 'docx'
      ? await (await import('./exportDocx')).exportDocx(record)
      : await (await import('./exportPdf')).exportPdf(record)
  downloadBlob(blob, `${safeFileName(record.title)}.${kind}`)
}
