import { createContext, useCallback, useContext, useMemo, useRef, useState, type ReactNode } from 'react'
import { AlertTriangle, CheckCircle2 } from 'lucide-react'

type ToastKind = 'success' | 'error'
interface ToastItem {
  id: number
  message: string
  kind: ToastKind
}
type ToastFn = (message: string, kind?: ToastKind) => void

const ToastContext = createContext<ToastFn>(() => {})
export const useToast = (): ToastFn => useContext(ToastContext)

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([])
  const seq = useRef(0)

  const push = useCallback<ToastFn>((message, kind = 'success') => {
    const id = ++seq.current
    setItems((list) => [...list.slice(-3), { id, message, kind }])
    window.setTimeout(() => setItems((list) => list.filter((t) => t.id !== id)), kind === 'error' ? 6000 : 3000)
  }, [])

  const value = useMemo(() => push, [push])

  return (
    <ToastContext.Provider value={value}>
      {children}
      <div
        aria-live="polite"
        className="pointer-events-none fixed inset-x-0 bottom-4 z-[80] flex flex-col items-center gap-2 px-4"
        style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
      >
        {items.map((t) => (
          <div
            key={t.id}
            role="status"
            className="panel pointer-events-auto flex max-w-md items-center gap-2.5 px-3.5 py-2.5 text-sm animate-pop"
          >
            {t.kind === 'success' ? (
              <CheckCircle2 size={18} className="shrink-0 text-emerald-500" />
            ) : (
              <AlertTriangle size={18} className="shrink-0 text-red-500" />
            )}
            <span>{t.message}</span>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  )
}
