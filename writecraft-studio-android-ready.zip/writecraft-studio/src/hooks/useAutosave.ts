import { useCallback, useEffect, useRef, useState } from 'react'

export type SaveStatus = 'saved' | 'dirty' | 'saving' | 'error'

/**
 * Autosave dengan jeda (debounce). `schedule()` menandai ada perubahan;
 * `flush()` menyimpan segera. Perubahan yang belum tersimpan juga di-flush saat
 * tab disembunyikan, ditutup, atau komponen dilepas.
 */
export function useAutosave(save: () => Promise<void>, delay: number) {
  const [status, setStatus] = useState<SaveStatus>('saved')
  const [savedAt, setSavedAt] = useState<number | null>(null)
  const timer = useRef<number | undefined>(undefined)
  const dirty = useRef(false)
  const saveRef = useRef(save)
  saveRef.current = save

  const flush = useCallback(async () => {
    window.clearTimeout(timer.current)
    if (!dirty.current) return
    dirty.current = false
    setStatus('saving')
    try {
      await saveRef.current()
      setStatus(dirty.current ? 'dirty' : 'saved')
      setSavedAt(Date.now())
    } catch {
      dirty.current = true
      setStatus('error')
    }
  }, [])

  const schedule = useCallback(() => {
    dirty.current = true
    setStatus('dirty')
    window.clearTimeout(timer.current)
    timer.current = window.setTimeout(() => void flush(), delay)
  }, [delay, flush])

  useEffect(() => {
    const onHide = () => {
      if (document.visibilityState === 'hidden') void flush()
    }
    const onUnload = (e: BeforeUnloadEvent) => {
      if (dirty.current) {
        void flush()
        e.preventDefault()
        e.returnValue = ''
      }
    }
    document.addEventListener('visibilitychange', onHide)
    window.addEventListener('beforeunload', onUnload)
    return () => {
      document.removeEventListener('visibilitychange', onHide)
      window.removeEventListener('beforeunload', onUnload)
      void flush()
    }
  }, [flush])

  return { status, savedAt, schedule, flush }
}
