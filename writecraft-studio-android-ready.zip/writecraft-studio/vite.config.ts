import { defineConfig } from 'vitest/config'
import react from '@vitejs/plugin-react'

// base './' membuat hasil build bisa dihosting di subfolder (mis. GitHub Pages).
export default defineConfig({
  base: './',
  plugins: [react()],
  build: {
    chunkSizeWarningLimit: 1500,
  },
  test: {
    environment: 'node',
    include: ['tests/**/*.test.ts'],
  },
})
