import type { AppSettings, DocSettings } from '../types'

const KEY = 'wc-settings'

export const DEFAULT_SETTINGS: AppSettings = {
  theme: 'system',
  defaultPageSize: 'A4',
  defaultOrientation: 'portrait',
  defaultFontFamily: 'Arial',
  defaultFontSize: 12,
  defaultLineHeight: 1.15,
  autosaveDelay: 800,
}

function read(): AppSettings {
  try {
    const raw = localStorage.getItem(KEY)
    return raw ? { ...DEFAULT_SETTINGS, ...JSON.parse(raw) } : DEFAULT_SETTINGS
  } catch {
    return DEFAULT_SETTINGS
  }
}

let current: AppSettings = read()
const listeners = new Set<() => void>()

export const getSettings = (): AppSettings => current

export function updateSettings(patch: Partial<AppSettings>): void {
  current = { ...current, ...patch }
  try {
    localStorage.setItem(KEY, JSON.stringify(current))
  } catch {
    /* penyimpanan penuh / diblokir — pengaturan tetap berlaku selama sesi */
  }
  listeners.forEach((l) => l())
}

export function subscribeSettings(listener: () => void): () => void {
  listeners.add(listener)
  return () => {
    listeners.delete(listener)
  }
}

/** Pengaturan dokumen baru berdasarkan preferensi aplikasi. */
export function defaultDocSettings(app: AppSettings = current): DocSettings {
  return {
    pageSize: app.defaultPageSize,
    orientation: app.defaultOrientation,
    margins: { top: 2.54, bottom: 2.54, left: 2.54, right: 2.54 },
    fontFamily: app.defaultFontFamily,
    fontSize: app.defaultFontSize,
    lineHeight: app.defaultLineHeight,
    header: '',
    footer: '',
    showPageNumber: false,
  }
}
