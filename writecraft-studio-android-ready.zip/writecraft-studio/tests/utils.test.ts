import { describe, expect, it } from 'vitest'
import { docToPlainText, previewText, firstFamily } from '../src/utils/doc'
import { toHex } from '../src/utils/color'
import { getPageDims } from '../src/utils/page'
import { tableGrid } from '../src/utils/tableGrid'
import { sanitize, formatListNumber } from '../src/services/exportPdf'
import { makeRecord } from './fixtures'

describe('utils', () => {
  it('mengubah dokumen menjadi teks polos', () => {
    const rec = makeRecord('surat')
    expect(docToPlainText(rec.content)).toContain('Dengan hormat,')
    expect(previewText(rec.content, 20).length).toBeLessThanOrEqual(21)
  })

  it('mengonversi warna ke hex', () => {
    expect(toHex('#abc')).toBe('AABBCC')
    expect(toHex('rgb(255, 0, 10)')).toBe('FF000A')
    expect(toHex('merah')).toBeNull()
  })

  it('menukar dimensi saat landscape', () => {
    expect(getPageDims({ pageSize: 'A4', orientation: 'landscape' })).toEqual({ width: 29.7, height: 21 })
  })

  it('mengambil nama font pertama', () => {
    expect(firstFamily('"Times New Roman", Times, serif')).toBe('Times New Roman')
  })

  it('menghitung grid tabel', () => {
    const tbl = makeRecord('laporan').content.content!.find((n) => n.type === 'table')!
    const g = tableGrid(tbl)
    expect(g.cols).toBe(3)
    expect(g.fractions.reduce((a, b) => a + b, 0)).toBeCloseTo(1)
  })

  it('membersihkan karakter yang tak didukung PDF', () => {
    expect(sanitize('Halo “dunia” – 日本')).toBe('Halo “dunia” – ??')
    expect(formatListNumber(3, 1)).toBe('c.')
    expect(formatListNumber(4, 2)).toBe('iv.')
  })
})
