import { useSyncExternalStore } from 'react'
import { getSettings, subscribeSettings } from '../services/settings'
import type { AppSettings } from '../types'

export function useAppSettings(): AppSettings {
  return useSyncExternalStore(subscribeSettings, getSettings)
}
