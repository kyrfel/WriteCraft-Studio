import { useEffect, useState } from 'react'
import type { Editor } from '@tiptap/core'

/** Render ulang komponen setiap kali state editor berubah (seleksi, isi, format). */
export function useEditorTick(editor: Editor | null): void {
  const [, setTick] = useState(0)
  useEffect(() => {
    if (!editor) return
    const bump = () => setTick((n) => n + 1)
    editor.on('transaction', bump)
    return () => {
      editor.off('transaction', bump)
    }
  }, [editor])
}
