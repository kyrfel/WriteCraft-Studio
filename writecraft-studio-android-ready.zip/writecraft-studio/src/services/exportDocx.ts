import {
  AlignmentType,
  BorderStyle,
  Document,
  ExternalHyperlink,
  Footer,
  Header,
  HeadingLevel,
  ImageRun,
  LevelFormat,
  LineRuleType,
  Packer,
  PageBreak,
  PageNumber,
  PageOrientation,
  Paragraph,
  ShadingType,
  Table,
  TableCell,
  TableLayoutType,
  TableRow,
  TextRun,
  UnderlineType,
  WidthType,
} from 'docx'
import type { IParagraphOptions, IRunOptions } from 'docx'
import type { DocNode, DocSettings, DocumentRecord } from '../types'
import { toHex } from '../utils/color'
import { collectImageSrcs, firstFamily } from '../utils/doc'
import { CM_TO_TWIP, PAGE_SIZES, getContentSizeCm } from '../utils/page'
import { tableGrid } from '../utils/tableGrid'
import { rasterizeAll, type ImageMap } from './imageUtils'

type Block = Paragraph | Table
/** IRunOptions bersifat read-only; kita butuh versi yang bisa diubah saat menyusun properti. */
type RunOpts = { -readonly [K in keyof IRunOptions]: IRunOptions[K] }
type Align = NonNullable<IParagraphOptions['alignment']>

interface Ctx {
  settings: DocSettings
  images: ImageMap
  contentWidthPx: number
  listCounter: { n: number }
  cell: boolean
  quote: boolean
}

const ALIGN: Record<string, Align> = {
  left: AlignmentType.LEFT,
  center: AlignmentType.CENTER,
  right: AlignmentType.RIGHT,
  justify: AlignmentType.JUSTIFIED,
}

const HEADING = {
  1: HeadingLevel.HEADING_1,
  2: HeadingLevel.HEADING_2,
  3: HeadingLevel.HEADING_3,
} as const

const LIST_INDENT = 540 // twips per tingkat (27 pt)

function runProps(marks: DocNode['marks'] = [], base: RunOpts = {}): RunOpts {
  const o: RunOpts = { ...base }
  for (const m of marks) {
    switch (m.type) {
      case 'bold':
        o.bold = true
        break
      case 'italic':
        o.italics = true
        break
      case 'underline':
        o.underline = { type: UnderlineType.SINGLE }
        break
      case 'strike':
        o.strike = true
        break
      case 'subscript':
        o.subScript = true
        break
      case 'superscript':
        o.superScript = true
        break
      case 'code':
        o.font = 'Courier New'
        break
      case 'highlight':
        o.shading = { type: ShadingType.CLEAR, fill: toHex(m.attrs?.color) ?? 'FFFF00', color: 'auto' }
        break
      case 'link':
        o.color = '0563C1'
        o.underline = { type: UnderlineType.SINGLE }
        break
      case 'textStyle': {
        const a = m.attrs ?? {}
        const c = toHex(a.color)
        if (c) o.color = c
        if (a.fontFamily) o.font = firstFamily(String(a.fontFamily))
        if (a.fontSize) {
          const pt = parseFloat(String(a.fontSize))
          if (pt > 0) o.size = Math.round(pt * 2)
        }
        break
      }
    }
  }
  return o
}

function inlineRuns(nodes: DocNode[] | undefined, base: RunOpts = {}): (TextRun | ExternalHyperlink)[] {
  const out: (TextRun | ExternalHyperlink)[] = []
  for (const n of nodes ?? []) {
    if (n.type === 'text') {
      const run = new TextRun({ ...runProps(n.marks, base), text: n.text ?? '' })
      const link = n.marks?.find((m) => m.type === 'link')
      const href = link?.attrs?.href
      out.push(href ? new ExternalHyperlink({ link: String(href), children: [run] }) : run)
    } else if (n.type === 'hardBreak') {
      out.push(new TextRun({ break: 1 }))
    }
  }
  return out
}

interface ParaOpts {
  level?: number
  numbering?: { reference: string; level: number; instance?: number }
  compact?: boolean
}

function paragraph(n: DocNode, ctx: Ctx, opts: ParaOpts = {}): Paragraph {
  const a = n.attrs ?? {}
  const lh = Number(a.lineHeight) || ctx.settings.lineHeight
  const base: RunOpts = {}
  if (ctx.quote) {
    base.italics = true
    base.color = '555555'
  }
  const heading = opts.level ? HEADING[opts.level as 1 | 2 | 3] : undefined
  const indentLeft = (Number(a.indent) || 0) * 720 + (ctx.quote ? 720 : 0)
  let spacing = { before: 0, after: 120 }
  if (ctx.cell) spacing = { before: 0, after: 0 }
  else if (opts.compact) spacing = { before: 0, after: 40 }
  else if (opts.level) spacing = { before: 240, after: 120 }
  return new Paragraph({
    children: inlineRuns(n.content, base),
    alignment: a.textAlign ? ALIGN[String(a.textAlign)] : undefined,
    heading,
    numbering: opts.numbering,
    spacing: { ...spacing, line: Math.round(240 * lh), lineRule: LineRuleType.AUTO },
    indent: indentLeft && !opts.numbering ? { left: indentLeft } : undefined,
    border: ctx.quote ? { left: { style: BorderStyle.SINGLE, size: 12, color: 'AAAAAA', space: 8 } } : undefined,
  })
}

function listParagraphs(list: DocNode, ctx: Ctx, level: number, ordered: boolean, instance: number): Block[] {
  const out: Block[] = []
  for (const li of list.content ?? []) {
    let first = true
    for (const child of li.content ?? []) {
      if (child.type === 'paragraph') {
        out.push(
          paragraph(child, ctx, {
            compact: true,
            numbering: first
              ? {
                  reference: ordered ? 'ordered' : 'bullet',
                  level: Math.min(level, 5),
                  ...(ordered ? { instance } : {}),
                }
              : undefined,
          }),
        )
        first = false
      } else if (child.type === 'bulletList') {
        out.push(...listParagraphs(child, ctx, level + 1, false, instance))
      } else if (child.type === 'orderedList') {
        out.push(...listParagraphs(child, ctx, level + 1, true, instance))
      } else {
        out.push(...convertBlock(child, ctx))
      }
    }
  }
  return out
}

function convertBlocks(nodes: DocNode[] | undefined, ctx: Ctx): Block[] {
  const out: Block[] = []
  for (const n of nodes ?? []) out.push(...convertBlock(n, ctx))
  return out
}

function convertBlock(n: DocNode, ctx: Ctx): Block[] {
  switch (n.type) {
    case 'paragraph':
      return [paragraph(n, ctx)]
    case 'heading':
      return [paragraph(n, ctx, { level: Math.min(3, Math.max(1, Number(n.attrs?.level) || 1)) })]
    case 'bulletList':
      return listParagraphs(n, ctx, 0, false, 0)
    case 'orderedList':
      ctx.listCounter.n += 1
      return listParagraphs(n, ctx, 0, true, ctx.listCounter.n)
    case 'blockquote':
      return convertBlocks(n.content, { ...ctx, quote: true })
    case 'codeBlock': {
      const text = (n.content ?? []).map((c) => c.text ?? '').join('')
      const lines = text.split('\n')
      return lines.map(
        (line, i) =>
          new Paragraph({
            children: [new TextRun({ text: line, font: 'Courier New', size: 20 })],
            shading: { type: ShadingType.CLEAR, fill: 'F3F4F6', color: 'auto' },
            spacing: { before: 0, after: i === lines.length - 1 ? 120 : 0 },
          }),
      )
    }
    case 'horizontalRule':
      return [
        new Paragraph({
          children: [],
          spacing: { before: 120, after: 120 },
          border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: '999999', space: 1 } },
        }),
      ]
    case 'pageBreak':
      return [new Paragraph({ children: [new PageBreak()] })]
    case 'image':
      return [imageParagraph(n, ctx)]
    case 'table':
      return [tableBlock(n, ctx)]
    default:
      return n.content ? convertBlocks(n.content, ctx) : []
  }
}

function imageParagraph(n: DocNode, ctx: Ctx): Paragraph {
  const src = String(n.attrs?.src ?? '')
  const r = ctx.images.get(src)
  if (!r) {
    return new Paragraph({
      children: [new TextRun({ text: '[Gambar tidak dapat diekspor]', italics: true, color: '888888' })],
    })
  }
  const w = Math.min(Number(n.attrs?.width) || r.width, ctx.contentWidthPx)
  const h = Math.max(1, Math.round((w * r.height) / r.width))
  return new Paragraph({
    alignment: ALIGN[String(n.attrs?.align ?? 'left')] ?? AlignmentType.LEFT,
    spacing: { before: 60, after: 120 },
    children: [
      new ImageRun({
        type: r.format === 'JPEG' ? 'jpg' : 'png',
        data: r.bytes,
        transformation: { width: Math.round(w), height: h },
      }),
    ],
  })
}

function tableBlock(n: DocNode, ctx: Ctx): Table {
  const totalTwips = Math.round(ctx.contentWidthPx * 15)
  const { fractions } = tableGrid(n)
  const colWidths = fractions.map((f) => Math.max(200, Math.round(f * totalTwips)))
  const line = { style: BorderStyle.SINGLE, size: 4, color: '999999' }
  const rows = (n.content ?? []).map((row) => {
    let col = 0
    const cells = (row.content ?? []).map((cell) => {
      const span = Math.max(1, Number(cell.attrs?.colspan) || 1)
      const rowSpan = Math.max(1, Number(cell.attrs?.rowspan) || 1)
      const width = colWidths.slice(col, col + span).reduce((a, b) => a + b, 0) || colWidths[0]
      col += span
      const isHeader = cell.type === 'tableHeader'
      let children: Block[] = convertBlocks(cell.content, { ...ctx, cell: true })
      if (isHeader) {
        children = convertBlocks(boldify(cell.content), { ...ctx, cell: true })
      }
      if (children.length === 0) children = [new Paragraph({ children: [] })]
      return new TableCell({
        children,
        width: { size: width, type: WidthType.DXA },
        columnSpan: span > 1 ? span : undefined,
        rowSpan: rowSpan > 1 ? rowSpan : undefined,
        shading: isHeader ? { type: ShadingType.CLEAR, fill: 'F1F1F1', color: 'auto' } : undefined,
        margins: { top: 60, bottom: 60, left: 100, right: 100 },
      })
    })
    return new TableRow({ children: cells })
  })
  return new Table({
    rows,
    width: { size: colWidths.reduce((a, b) => a + b, 0), type: WidthType.DXA },
    columnWidths: colWidths,
    layout: TableLayoutType.FIXED,
    borders: {
      top: line,
      bottom: line,
      left: line,
      right: line,
      insideHorizontal: line,
      insideVertical: line,
    },
  })
}

/** Tambahkan mark bold ke seluruh teks (untuk sel header tabel). */
function boldify(nodes: DocNode[] | undefined): DocNode[] {
  const walk = (n: DocNode): DocNode => {
    if (n.type === 'text') {
      const marks = n.marks ?? []
      return marks.some((m) => m.type === 'bold') ? n : { ...n, marks: [...marks, { type: 'bold' }] }
    }
    return n.content ? { ...n, content: n.content.map(walk) } : n
  }
  return (nodes ?? []).map(walk)
}

function levelsFor(kind: 'bullet' | 'ordered') {
  const bulletChars = ['•', '◦', '▪', '•', '◦', '▪']
  const orderedFormats = [LevelFormat.DECIMAL, LevelFormat.LOWER_LETTER, LevelFormat.LOWER_ROMAN]
  return Array.from({ length: 6 }, (_, i) => ({
    level: i,
    format: kind === 'bullet' ? LevelFormat.BULLET : orderedFormats[i % 3],
    text: kind === 'bullet' ? bulletChars[i] : `%${i + 1}.`,
    alignment: AlignmentType.LEFT,
    style: { paragraph: { indent: { left: LIST_INDENT * (i + 1), hanging: LIST_INDENT / 2 } } },
  }))
}

export function buildDocx(record: DocumentRecord, images: ImageMap = new Map()): Document {
  const s = record.settings
  const base = PAGE_SIZES[s.pageSize]
  const content = getContentSizeCm(s)
  const ctx: Ctx = {
    settings: s,
    images,
    contentWidthPx: (content.width * 96) / 2.54,
    listCounter: { n: 0 },
    cell: false,
    quote: false,
  }

  let children: Block[] = convertBlocks(record.content.content, ctx)
  if (children.length === 0) children = [new Paragraph({ children: [] })]

  const gray = { color: '777777', size: 18 }
  const headerText = s.header.trim()
  const footerText = s.footer.trim()
  const footerChildren: Paragraph[] = []
  if (footerText) {
    footerChildren.push(
      new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: footerText, ...gray })] }),
    )
  }
  if (s.showPageNumber) {
    footerChildren.push(
      new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [new TextRun({ children: ['Halaman ', PageNumber.CURRENT, ' dari ', PageNumber.TOTAL_PAGES], ...gray })],
      }),
    )
  }

  const font = s.fontFamily
  const headingStyle = (id: string, name: string, size: number) => ({
    id,
    name,
    basedOn: 'Normal',
    next: 'Normal',
    quickFormat: true,
    run: { size: size * 2, bold: true, color: '000000', font },
    paragraph: { keepNext: true },
  })

  return new Document({
    creator: 'WriteCraft Studio',
    title: record.title,
    styles: {
      default: { document: { run: { font, size: Math.round(s.fontSize * 2) } } },
      paragraphStyles: [
        headingStyle('Heading1', 'Heading 1', 24),
        headingStyle('Heading2', 'Heading 2', 18),
        headingStyle('Heading3', 'Heading 3', 14),
      ],
    },
    numbering: {
      config: [
        { reference: 'bullet', levels: levelsFor('bullet') },
        { reference: 'ordered', levels: levelsFor('ordered') },
      ],
    },
    sections: [
      {
        properties: {
          page: {
            // docx menukar lebar/tinggi sendiri untuk landscape, jadi kirim ukuran potret.
            size: {
              width: Math.round(base.width * CM_TO_TWIP),
              height: Math.round(base.height * CM_TO_TWIP),
              orientation: s.orientation === 'landscape' ? PageOrientation.LANDSCAPE : PageOrientation.PORTRAIT,
            },
            margin: {
              top: Math.round(s.margins.top * CM_TO_TWIP),
              bottom: Math.round(s.margins.bottom * CM_TO_TWIP),
              left: Math.round(s.margins.left * CM_TO_TWIP),
              right: Math.round(s.margins.right * CM_TO_TWIP),
              header: 708,
              footer: 708,
            },
          },
        },
        headers: headerText
          ? {
              default: new Header({
                children: [
                  new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: headerText, ...gray })] }),
                ],
              }),
            }
          : undefined,
        footers: footerChildren.length ? { default: new Footer({ children: footerChildren }) } : undefined,
        children,
      },
    ],
  })
}

/** Hasilkan berkas .docx valid dari dokumen WriteCraft. */
export async function exportDocx(record: DocumentRecord): Promise<Blob> {
  const images = await rasterizeAll(collectImageSrcs(record.content))
  return Packer.toBlob(buildDocx(record, images))
}
