/** Ubah warna CSS (#rgb, #rrggbb, rgb(...)) menjadi 'RRGGBB' tanpa '#'. */
export function toHex(color?: string | null): string | null {
  if (!color) return null
  const c = color.trim().toLowerCase()
  let m = /^#([0-9a-f]{6})$/.exec(c)
  if (m) return m[1].toUpperCase()
  m = /^#([0-9a-f]{3})$/.exec(c)
  if (m) return m[1].split('').map((x) => x + x).join('').toUpperCase()
  const rgb = /^rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})/.exec(c)
  if (rgb) {
    return [rgb[1], rgb[2], rgb[3]]
      .map((v) => Math.max(0, Math.min(255, parseInt(v, 10))).toString(16).padStart(2, '0'))
      .join('')
      .toUpperCase()
  }
  return null
}

export function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace('#', '')
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)]
}
