import CharacterCount from '@tiptap/extension-character-count'
import { Color } from '@tiptap/extension-color'
import FontFamily from '@tiptap/extension-font-family'
import Highlight from '@tiptap/extension-highlight'
import Link from '@tiptap/extension-link'
import Placeholder from '@tiptap/extension-placeholder'
import Subscript from '@tiptap/extension-subscript'
import Superscript from '@tiptap/extension-superscript'
import Table from '@tiptap/extension-table'
import TableCell from '@tiptap/extension-table-cell'
import TableHeader from '@tiptap/extension-table-header'
import TableRow from '@tiptap/extension-table-row'
import TextAlign from '@tiptap/extension-text-align'
import TextStyle from '@tiptap/extension-text-style'
import Underline from '@tiptap/extension-underline'
import StarterKit from '@tiptap/starter-kit'
import { FontSize } from './extensions/FontSize'
import { PageBreak } from './extensions/PageBreak'
import { ParagraphStyle } from './extensions/ParagraphStyle'
import { ResizableImage } from './extensions/ResizableImage'
import { SearchReplace } from './extensions/SearchReplace'

/** Kumpulan ekstensi editor — dipakai juga oleh impor DOCX agar skema dokumennya sama. */
export function buildExtensions(placeholder = 'Mulai menulis…') {
  return [
    StarterKit.configure({ heading: { levels: [1, 2, 3] } }),
    Underline,
    TextStyle,
    Color,
    FontFamily,
    FontSize,
    Highlight.configure({ multicolor: true }),
    Subscript,
    Superscript,
    TextAlign.configure({ types: ['heading', 'paragraph'] }),
    ParagraphStyle,
    Link.configure({
      openOnClick: false,
      autolink: true,
      linkOnPaste: true,
      HTMLAttributes: { rel: 'noopener noreferrer nofollow', target: '_blank' },
    }),
    ResizableImage.configure({ allowBase64: true, inline: false }),
    Table.configure({ resizable: true }),
    TableRow,
    TableHeader,
    TableCell,
    PageBreak,
    Placeholder.configure({ placeholder }),
    CharacterCount,
    SearchReplace,
  ]
}
