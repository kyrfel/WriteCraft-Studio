/** Miniatur kertas yang menggambarkan susunan tiap template. */
const PATTERNS: Record<string, string[]> = {
  blank: [],
  surat: ['cc', 'cs', 'r', 'g', 'sr', 'g', 'l', 'l', 'g', 'l', 'l', 'l', 'g', 'l', 's'],
  laporan: ['h', 's', 'g', 'l', 'l', 'T', 'g', 'l', 'l'],
  makalah: ['g', 'g', 'Hc', 'cs', 'g', 'g', 'c', 'c', 'g', 'g', 'c'],
  proposal: ['h', 's', 'g', 'b', 'b', 'g', 'T', 'g', 'T'],
  resume: ['H', 's', 'r', 'h', 'l', 'l', 'g', 'h', 'b', 'b'],
  catatan: ['h', 'g', 'b', 'b', 'b', 'g', 'h', 'b'],
}

const bar = (w: string, cls = 'bg-slate-300', extra = '') => (
  <div className={`h-[3px] rounded-full ${cls} ${extra}`} style={{ width: w }} />
)

function row(kind: string, i: number) {
  switch (kind) {
    case 'g':
      return <div key={i} className="h-1.5" />
    case 'h':
      return <div key={i}>{bar('45%', 'bg-slate-500', '!h-1')}</div>
    case 'H':
      return <div key={i}>{bar('62%', 'bg-slate-600', '!h-1.5')}</div>
    case 'Hc':
      return <div key={i} className="flex justify-center">{bar('62%', 'bg-slate-600', '!h-1.5')}</div>
    case 'l':
      return <div key={i}>{bar('100%')}</div>
    case 's':
      return <div key={i}>{bar('60%')}</div>
    case 'c':
      return <div key={i} className="flex justify-center">{bar('55%')}</div>
    case 'cc':
      return <div key={i} className="flex justify-center">{bar('70%', 'bg-slate-500')}</div>
    case 'cs':
      return <div key={i} className="flex justify-center">{bar('48%')}</div>
    case 'sr':
      return <div key={i} className="flex justify-end">{bar('35%')}</div>
    case 'r':
      return <div key={i} className="my-0.5 h-px bg-slate-400" />
    case 'b':
      return (
        <div key={i} className="flex items-center gap-1">
          <span className="h-[3px] w-[3px] rounded-full bg-slate-400" />
          {bar('78%')}
        </div>
      )
    case 'T':
      return (
        <div key={i} className="grid grid-cols-3 border border-slate-300">
          {Array.from({ length: 9 }).map((_, c) => (
            <div key={c} className={`h-1.5 border-slate-300 ${c % 3 !== 2 ? 'border-r' : ''} ${c < 6 ? 'border-b' : ''} ${c < 3 ? 'bg-slate-100' : ''}`} />
          ))}
        </div>
      )
    default:
      return null
  }
}

export function TemplateThumb({ id, className = '' }: { id: string; className?: string }) {
  const pattern = PATTERNS[id] ?? []
  return (
    <div
      className={`relative flex aspect-[3/4] flex-col gap-[3px] overflow-hidden rounded-[3px] border border-slate-200 bg-white p-2 shadow-sm ${className}`}
      aria-hidden="true"
    >
      {pattern.length === 0 ? (
        <span className="m-auto text-xl font-light text-slate-300">+</span>
      ) : (
        pattern.map((k, i) => row(k, i))
      )}
    </div>
  )
}
