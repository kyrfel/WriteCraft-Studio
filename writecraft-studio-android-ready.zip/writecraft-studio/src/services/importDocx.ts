import { Editor } from '@tiptap/core'
import type { DocNode } from '../types'
import { buildExtensions } from '../editor/extensions'

/**
 * Baca berkas .docx dengan Mammoth (DOCX → HTML) lalu ubah HTML itu menjadi
 * JSON TipTap memakai editor tanpa antarmuka.
 */
export async function importDocx(file: File): Promise<{ title: string; content: DocNode; warnings: string[] }> {
  const arrayBuffer = await file.arrayBuffer()
  const mammoth = (await import('mammoth/mammoth.browser')).default
  const result = await mammoth.convertToHtml({ arrayBuffer })

  const editor = new Editor({ extensions: buildExtensions(), content: result.value || '<p></p>' })
  const content = editor.getJSON() as DocNode
  editor.destroy()

  return {
    title: file.name.replace(/\.docx$/i, '') || 'Dokumen impor',
    content,
    warnings: result.messages.filter((m) => m.type === 'warning').map((m) => m.message),
  }
}
