import { openDB, type DBSchema, type IDBPDatabase } from 'idb'
import type { DocumentRecord } from '../types'
import { uid } from '../utils/format'

interface WriteCraftDB extends DBSchema {
  documents: {
    key: string
    value: DocumentRecord
    indexes: { 'by-updated': number }
  }
}

const DB_NAME = 'writecraft-studio'
let dbPromise: Promise<IDBPDatabase<WriteCraftDB>> | null = null

function db(): Promise<IDBPDatabase<WriteCraftDB>> {
  if (!dbPromise) {
    dbPromise = openDB<WriteCraftDB>(DB_NAME, 1, {
      upgrade(database) {
        const store = database.createObjectStore('documents', { keyPath: 'id' })
        store.createIndex('by-updated', 'updatedAt')
      },
    })
  }
  return dbPromise
}

const listeners = new Set<() => void>()
const notify = () => listeners.forEach((l) => l())

/** Dengarkan perubahan daftar dokumen (tambah/ubah/hapus). */
export function subscribeDocuments(listener: () => void): () => void {
  listeners.add(listener)
  return () => {
    listeners.delete(listener)
  }
}

/** Minta browser agar tidak menghapus data situs ini saat ruang penyimpanan menipis. */
export async function requestPersistence(): Promise<boolean> {
  try {
    if (navigator.storage?.persist) return await navigator.storage.persist()
  } catch {
    /* diabaikan */
  }
  return false
}

export async function listDocuments(): Promise<DocumentRecord[]> {
  const all = await (await db()).getAll('documents')
  return all.sort((a, b) => b.updatedAt - a.updatedAt)
}

export async function getDocument(id: string): Promise<DocumentRecord | undefined> {
  return (await db()).get('documents', id)
}

export async function putDocument(record: DocumentRecord, notifyListeners = true): Promise<void> {
  await (await db()).put('documents', record)
  if (notifyListeners) notify()
}

export async function deleteDocument(id: string): Promise<void> {
  await (await db()).delete('documents', id)
  notify()
}

export async function renameDocument(id: string, title: string): Promise<void> {
  const rec = await getDocument(id)
  if (!rec) return
  await putDocument({ ...rec, title: title.trim() || 'Tanpa judul', updatedAt: Date.now() })
}

function clone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T
}

export async function duplicateDocument(id: string): Promise<DocumentRecord | undefined> {
  const rec = await getDocument(id)
  if (!rec) return undefined
  const now = Date.now()
  const copy: DocumentRecord = {
    ...rec,
    id: uid(),
    title: `${rec.title} (salinan)`,
    content: clone(rec.content),
    settings: clone(rec.settings),
    createdAt: now,
    updatedAt: now,
  }
  await putDocument(copy)
  return copy
}

/** Cadangan seluruh dokumen sebagai teks JSON. */
export async function exportBackup(): Promise<string> {
  const docs = await listDocuments()
  return JSON.stringify({ app: 'writecraft-studio', version: 1, exportedAt: Date.now(), documents: docs })
}

/** Pulihkan dokumen dari cadangan. Mengembalikan jumlah dokumen yang diimpor. */
export async function importBackup(json: string): Promise<number> {
  const data = JSON.parse(json) as { app?: string; documents?: DocumentRecord[] }
  if (data.app !== 'writecraft-studio' || !Array.isArray(data.documents)) {
    throw new Error('Berkas bukan cadangan WriteCraft Studio yang valid.')
  }
  const database = await db()
  let count = 0
  for (const d of data.documents) {
    if (!d || typeof d.id !== 'string' || !d.content || !d.settings) continue
    await database.put('documents', d)
    count++
  }
  notify()
  return count
}

export async function clearAllDocuments(): Promise<void> {
  await (await db()).clear('documents')
  notify()
}
