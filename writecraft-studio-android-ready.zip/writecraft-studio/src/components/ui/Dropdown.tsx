import { useCallback, useEffect, useLayoutEffect, useRef, useState, type ReactNode } from 'react'
import { createPortal } from 'react-dom'

interface DropdownProps {
  trigger: ReactNode
  children: ReactNode | ((close: () => void) => ReactNode)
  label: string
  align?: 'left' | 'right'
  className?: string
  active?: boolean
  disabled?: boolean
}

/**
 * Menu popover yang dirender lewat portal (position: fixed) sehingga tidak terpotong
 * oleh toolbar yang bisa digulir. Tidak mencuri fokus dari editor.
 */
export function Dropdown({ trigger, children, label, align = 'left', className = 'tb-btn', active, disabled }: DropdownProps) {
  const [open, setOpen] = useState(false)
  const [pos, setPos] = useState({ top: 0, left: 0 })
  const btnRef = useRef<HTMLButtonElement>(null)
  const panelRef = useRef<HTMLDivElement>(null)
  const close = useCallback(() => setOpen(false), [])

  useLayoutEffect(() => {
    if (!open || !btnRef.current) return
    const r = btnRef.current.getBoundingClientRect()
    const pw = panelRef.current?.offsetWidth ?? 220
    let left = align === 'right' ? r.right - pw : r.left
    left = Math.max(8, Math.min(left, window.innerWidth - pw - 8))
    setPos({ top: r.bottom + 6, left })
  }, [open, align])

  useEffect(() => {
    if (!open) return
    const onDown = (e: MouseEvent | TouchEvent) => {
      const target = e.target as Node
      if (panelRef.current?.contains(target) || btnRef.current?.contains(target)) return
      setOpen(false)
    }
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false)
    }
    const onResize = () => setOpen(false)
    document.addEventListener('mousedown', onDown)
    document.addEventListener('touchstart', onDown)
    document.addEventListener('keydown', onKey)
    window.addEventListener('resize', onResize)
    return () => {
      document.removeEventListener('mousedown', onDown)
      document.removeEventListener('touchstart', onDown)
      document.removeEventListener('keydown', onKey)
      window.removeEventListener('resize', onResize)
    }
  }, [open])

  return (
    <>
      <button
        ref={btnRef}
        type="button"
        className={className}
        title={label}
        aria-label={label}
        aria-haspopup="menu"
        aria-expanded={open}
        data-active={active ? 'true' : undefined}
        disabled={disabled}
        onMouseDown={(e) => e.preventDefault()}
        onClick={() => setOpen((o) => !o)}
      >
        {trigger}
      </button>
      {open &&
        createPortal(
          <div
            ref={panelRef}
            role="menu"
            style={{ position: 'fixed', top: pos.top, left: pos.left, maxHeight: `calc(100dvh - ${pos.top + 12}px)` }}
            className="panel thin-scroll z-[70] min-w-[11rem] max-w-[calc(100vw-16px)] overflow-y-auto p-1.5 animate-pop"
          >
            {typeof children === 'function' ? children(close) : children}
          </div>,
          document.body,
        )}
    </>
  )
}
