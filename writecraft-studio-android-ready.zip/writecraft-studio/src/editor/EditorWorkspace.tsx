import { useCallback, useEffect, useRef, useState, type CSSProperties } from 'react'
import { EditorContent, useEditor } from '@tiptap/react'
import type { Editor, JSONContent } from '@tiptap/core'
import { AlertTriangle, ArrowLeft, Check, Download, FileText, Loader2, Moon, PanelTop, Sun, ZoomIn, ZoomOut } from 'lucide-react'
import { PageHeader } from '../components/layout/PageHeader'
import { Dropdown } from '../components/ui/Dropdown'
import { useToast } from '../components/ui/Toast'
import { useAppSettings } from '../hooks/useAppSettings'
import { useAutosave, type SaveStatus } from '../hooks/useAutosave'
import { useEditorTick } from '../hooks/useEditorTick'
import { go, paths } from '../hooks/useHashRoute'
import { toggleTheme, useIsDark } from '../hooks/useTheme'
import { downloadDocument, type ExportKind } from '../services/download'
import { putDocument } from '../services/storage'
import type { DocCategory, DocNode, DocSettings, DocumentRecord } from '../types'
import { stackFor } from '../utils/constants'
import { formatClock } from '../utils/format'
import { CM_TO_PX, PAGE_SIZES, getPageDims } from '../utils/page'
import { DocumentSettingsDialog } from './DocumentSettingsDialog'
import { FindReplace } from './FindReplace'
import { Toolbar } from './Toolbar'
import { buildExtensions } from './extensions'
import { insertImageFiles } from './insertImage'

function SaveBadge({ status, savedAt }: { status: SaveStatus; savedAt: number | null }) {
  const base = 'flex shrink-0 items-center gap-1.5 text-xs'
  if (status === 'error') {
    return (
      <span className={`${base} text-red-600`} role="status">
        <AlertTriangle size={14} /> <span className="hidden sm:inline">Gagal menyimpan</span>
      </span>
    )
  }
  if (status === 'saving' || status === 'dirty') {
    return (
      <span className={`${base} text-muted`} role="status">
        <Loader2 size={14} className={status === 'saving' ? 'animate-spin' : ''} />
        <span className="hidden sm:inline">{status === 'saving' ? 'Menyimpan…' : 'Perubahan belum tersimpan'}</span>
      </span>
    )
  }
  return (
    <span className={`${base} text-muted`} role="status">
      <Check size={14} className="text-emerald-500" />
      <span className="hidden sm:inline">Tersimpan{savedAt ? ` ${formatClock(savedAt)}` : ''}</span>
    </span>
  )
}

function StatusBar({ editor, pages, pageLabel, zoom, onZoom, onFit }: {
  editor: Editor; pages: number; pageLabel: string; zoom: number; onZoom: (delta: number) => void; onFit: () => void
}) {
  useEditorTick(editor)
  const words = editor.storage.characterCount?.words?.() ?? 0
  const chars = editor.storage.characterCount?.characters?.() ?? 0
  return (
    <div className="flex h-8 shrink-0 items-center gap-3 border-t border-line bg-surface px-3 text-xs text-muted" style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
      <span>{words.toLocaleString('id-ID')} kata</span>
      <span>{chars.toLocaleString('id-ID')} karakter</span>
      <span className="hidden sm:inline">≈ {pages} halaman · {pageLabel}</span>
      <span className="ml-auto flex items-center gap-1">
        <button type="button" className="tb-btn h-6 min-w-[1.5rem]" aria-label="Perkecil" onClick={() => onZoom(-0.1)}><ZoomOut size={14} /></button>
        <button type="button" className="tb-btn h-6 px-1.5 text-xs" aria-label="Sesuaikan lebar layar" title="Sesuaikan lebar layar" onClick={onFit}>{Math.round(zoom * 100)}%</button>
        <button type="button" className="tb-btn h-6 min-w-[1.5rem]" aria-label="Perbesar" onClick={() => onZoom(0.1)}><ZoomIn size={14} /></button>
      </span>
    </div>
  )
}

export function EditorWorkspace({ initial }: { initial: DocumentRecord }) {
  const app = useAppSettings()
  const toast = useToast()
  const dark = useIsDark()

  const docRef = useRef<DocumentRecord>(initial)
  const editorRef = useRef<Editor | null>(null)
  const widthRef = useRef(0)
  const toastRef = useRef(toast)
  toastRef.current = toast

  const [title, setTitle] = useState(initial.title)
  const [category, setCategory] = useState<DocCategory>(initial.category)
  const [settings, setSettings] = useState<DocSettings>(initial.settings)
  const [findOpen, setFindOpen] = useState(false)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [busy, setBusy] = useState<ExportKind | null>(null)
  const [zoomMode, setZoomMode] = useState<'fit' | number>('fit')
  const [viewW, setViewW] = useState(0)
  const [contentH, setContentH] = useState(0)
  const scrollRef = useRef<HTMLDivElement>(null)
  const proseWrapRef = useRef<HTMLDivElement>(null)

  // useAutosave dipanggil sebelum useEditor agar flush saat unmount berjalan selagi editor masih hidup.
  const save = useCallback(async () => {
    const ed = editorRef.current
    let content = docRef.current.content
    try {
      if (ed) content = ed.getJSON() as DocNode
    } catch {
      /* editor sudah dihancurkan — pakai isi terakhir */
    }
    const rec: DocumentRecord = { ...docRef.current, content, updatedAt: Date.now() }
    docRef.current = rec
    await putDocument(rec)
  }, [])
  const { status, savedAt, schedule, flush } = useAutosave(save, app.autosaveDelay)
  const scheduleRef = useRef(schedule)
  scheduleRef.current = schedule

  const insertImages = (files: File[]) => {
    const ed = editorRef.current
    if (!ed) return
    insertImageFiles(ed, files, widthRef.current).catch(() => toastRef.current('Gagal menyisipkan gambar.', 'error'))
  }

  const editor = useEditor({
    extensions: buildExtensions(),
    content: initial.content as JSONContent,
    shouldRerenderOnTransaction: false,
    editorProps: {
      attributes: { class: 'wc-prose', spellcheck: 'true', lang: 'id' },
      handlePaste: (_view, event) => {
        const files = Array.from(event.clipboardData?.files ?? []).filter((f) => f.type.startsWith('image/'))
        if (!files.length) return false
        event.preventDefault()
        insertImages(files)
        return true
      },
      handleDrop: (_view, event) => {
        const files = Array.from(event.dataTransfer?.files ?? []).filter((f) => f.type.startsWith('image/'))
        if (!files.length) return false
        event.preventDefault()
        insertImages(files)
        return true
      },
    },
    onUpdate: () => scheduleRef.current(),
  })
  editorRef.current = editor

  // ---- geometri halaman ----
  const dims = getPageDims(settings)
  const pageW = dims.width * CM_TO_PX
  const pageH = dims.height * CM_TO_PX
  const mt = settings.margins.top * CM_TO_PX
  const mb = settings.margins.bottom * CM_TO_PX
  const ml = settings.margins.left * CM_TO_PX
  const mr = settings.margins.right * CM_TO_PX
  const contentWpx = pageW - ml - mr
  const contentHpx = pageH - mt - mb
  widthRef.current = contentWpx

  const fit = viewW ? Math.min(1, viewW / pageW) : 1
  const zoom = zoomMode === 'fit' ? fit : zoomMode
  const pages = Math.max(1, Math.ceil(contentH / contentHpx))

  useEffect(() => {
    const el = scrollRef.current
    if (!el) return
    const measure = () => {
      const cs = getComputedStyle(el)
      setViewW(el.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight))
    }
    measure()
    const ro = new ResizeObserver(measure)
    ro.observe(el)
    return () => ro.disconnect()
  }, [])

  useEffect(() => {
    const el = proseWrapRef.current
    if (!el) return
    const ro = new ResizeObserver(() => setContentH(el.offsetHeight))
    ro.observe(el)
    setContentH(el.offsetHeight)
    return () => ro.disconnect()
  }, [editor])

  // ---- pintasan keyboard ----
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!(e.ctrlKey || e.metaKey)) return
      const k = e.key.toLowerCase()
      if (k === 's') {
        e.preventDefault()
        void flush().then(() => toastRef.current('Dokumen tersimpan.'))
      } else if (k === 'f' || k === 'h') {
        e.preventDefault()
        setFindOpen(true)
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [flush])

  const onTitle = (value: string) => {
    setTitle(value)
    docRef.current = { ...docRef.current, title: value.trim() || 'Tanpa judul' }
    schedule()
  }

  const onSaveSettings = (s: DocSettings, c: DocCategory) => {
    setSettings(s)
    setCategory(c)
    docRef.current = { ...docRef.current, settings: s, category: c }
    schedule()
  }

  const doExport = async (kind: ExportKind) => {
    const ed = editorRef.current
    if (!ed) return
    setBusy(kind)
    try {
      await flush()
      const rec: DocumentRecord = { ...docRef.current, content: ed.getJSON() as DocNode }
      await downloadDocument(rec, kind)
      toast(`Berkas ${kind.toUpperCase()} berhasil diunduh.`)
    } catch (e) {
      console.error(e)
      toast(`Gagal mengekspor ${kind.toUpperCase()}. Coba lagi.`, 'error')
    } finally {
      setBusy(null)
    }
  }

  const sheetStyle = {
    width: pageW,
    minHeight: pageH,
    padding: `${mt}px ${mr}px ${mb}px ${ml}px`,
    '--wc-font': stackFor(settings.fontFamily),
    '--wc-size': `${settings.fontSize}pt`,
    '--wc-lh': settings.lineHeight,
  } as CSSProperties

  return (
    <>
      <PageHeader>
        <button type="button" className="btn-icon" onClick={() => go(paths.dashboard)} aria-label="Kembali ke dasbor" title="Kembali ke dasbor">
          <ArrowLeft size={18} />
        </button>
        <input
          className="h-9 min-w-0 flex-1 rounded-md bg-transparent px-2 text-sm font-semibold hover:bg-surface2 focus:bg-surface2 focus:outline-none"
          value={title}
          onChange={(e) => onTitle(e.target.value)}
          onBlur={() => !title.trim() && onTitle('Tanpa judul')}
          aria-label="Judul dokumen"
          placeholder="Judul dokumen"
        />
        <SaveBadge status={status} savedAt={savedAt} />
        <button type="button" className="btn-icon" onClick={() => setSettingsOpen(true)} aria-label="Tata letak dan dokumen" title="Tata letak dan dokumen">
          <PanelTop size={18} />
        </button>
        <button type="button" className="btn-icon hidden sm:inline-flex" onClick={toggleTheme} aria-label="Ganti tema" title="Ganti tema">
          {dark ? <Sun size={18} /> : <Moon size={18} />}
        </button>
        <Dropdown
          label="Ekspor dokumen"
          className="btn btn-primary"
          align="right"
          disabled={busy !== null || !editor}
          trigger={
            <>
              {busy ? <Loader2 size={16} className="animate-spin" /> : <Download size={16} />}
              <span className="hidden sm:inline">Ekspor</span>
            </>
          }
        >
          {(close) => (
            <div className="w-56">
              <button type="button" className="menu-item" onClick={() => { close(); void doExport('docx') }}>
                <FileText size={15} /> Unduh sebagai DOCX
              </button>
              <button type="button" className="menu-item" onClick={() => { close(); void doExport('pdf') }}>
                <FileText size={15} /> Unduh sebagai PDF
              </button>
              <p className="px-2.5 pb-1 pt-2 text-xs text-muted">Ukuran kertas {PAGE_SIZES[settings.pageSize].label.split(' ')[0]}, {settings.orientation === 'portrait' ? 'potret' : 'lanskap'}.</p>
            </div>
          )}
        </Dropdown>
      </PageHeader>

      {editor && (
        <>
          <Toolbar editor={editor} docSettings={settings} contentWidthPx={contentWpx} onFind={() => setFindOpen(true)} />
          {findOpen && <FindReplace editor={editor} onClose={() => { setFindOpen(false); editor.commands.focus() }} />}
        </>
      )}

      <div ref={scrollRef} className="thin-scroll min-h-0 flex-1 overflow-auto bg-surface2 p-3 sm:p-6">
        <div className="mx-auto" style={{ zoom, width: pageW }}>
          <div
            className="wc-sheet"
            style={sheetStyle}
            onMouseDown={(e) => {
              if (e.target === e.currentTarget) {
                e.preventDefault()
                editor?.commands.focus('end')
              }
            }}
          >
            {/* Header & footer tampil sebagai petunjuk di margin halaman */}
            {settings.header && (
              <div className="pointer-events-none absolute select-none text-right text-[11px] text-[#777]" style={{ top: Math.max(8, mt / 2 - 8), left: ml, right: mr }}>
                {settings.header}
              </div>
            )}
            {(settings.footer || settings.showPageNumber) && (
              <div className="pointer-events-none absolute select-none text-center text-[11px] leading-snug text-[#777]" style={{ bottom: Math.max(8, mb / 2 - 12), left: ml, right: mr }}>
                {settings.footer && <div>{settings.footer}</div>}
                {settings.showPageNumber && <div>Halaman 1 dari {pages}</div>}
              </div>
            )}

            {Array.from({ length: Math.max(0, pages - 1) }, (_, i) => (
              <div key={i} className="wc-pageguide" style={{ top: mt + (i + 1) * contentHpx }}>
                <span>Halaman {i + 2}</span>
              </div>
            ))}

            <div ref={proseWrapRef}>
              <EditorContent editor={editor} />
            </div>
          </div>
        </div>
      </div>

      {editor && (
        <StatusBar
          editor={editor}
          pages={pages}
          pageLabel={`${settings.pageSize} ${settings.orientation === 'portrait' ? 'potret' : 'lanskap'}`}
          zoom={zoom}
          onZoom={(d) => setZoomMode(Math.min(2, Math.max(0.3, Math.round((zoom + d) * 10) / 10)))}
          onFit={() => setZoomMode('fit')}
        />
      )}

      <DocumentSettingsDialog
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        settings={settings}
        category={category}
        onSave={onSaveSettings}
      />
    </>
  )
}
