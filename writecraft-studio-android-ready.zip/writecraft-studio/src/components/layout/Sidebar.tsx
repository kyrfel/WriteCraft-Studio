import { FilePlus2, FileText, LayoutDashboard, Moon, Settings, Sun, X } from 'lucide-react'
import { go, paths, type Route } from '../../hooks/useHashRoute'
import { useDocuments } from '../../hooks/useDocuments'
import { toggleTheme, useIsDark } from '../../hooks/useTheme'
import { createFromTemplate } from '../../services/documents'
import { relativeTime } from '../../utils/format'
import { useToast } from '../ui/Toast'
import { Logo } from '../ui/Logo'

interface SidebarProps {
  open: boolean
  onClose: () => void
  route: Route
}

export function Sidebar({ open, onClose, route }: SidebarProps) {
  const { docs } = useDocuments()
  const toast = useToast()
  const dark = useIsDark()

  const newDoc = async () => {
    try {
      const rec = await createFromTemplate('blank')
      go(paths.doc(rec.id))
    } catch {
      toast('Gagal membuat dokumen. Periksa penyimpanan browser.', 'error')
    }
  }

  const navItem = (active: boolean) =>
    `flex items-center gap-2.5 rounded-lg px-2.5 h-9 text-sm font-medium transition-colors ${
      active ? 'bg-brand/15 text-brand' : 'text-ink/80 hover:bg-surface2'
    }`

  return (
    <>
      {open && <div className="fixed inset-0 z-30 bg-black/40 animate-fade lg:hidden" onClick={onClose} />}
      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-[17rem] flex-col border-r border-line bg-surface transition-transform duration-200 lg:static lg:z-auto lg:translate-x-0 ${
          open ? 'translate-x-0' : '-translate-x-full'
        }`}
        style={{ paddingTop: 'env(safe-area-inset-top)', paddingBottom: 'env(safe-area-inset-bottom)' }}
      >
        <div className="flex h-14 items-center justify-between px-3.5">
          <a href="#/" aria-label="Ke dasbor">
            <Logo />
          </a>
          <button type="button" className="btn-icon lg:hidden" onClick={onClose} aria-label="Tutup menu">
            <X size={18} />
          </button>
        </div>

        <div className="px-3 pb-2">
          <button type="button" className="btn btn-primary w-full" onClick={newDoc}>
            <FilePlus2 size={16} /> Dokumen baru
          </button>
        </div>

        <nav className="space-y-0.5 px-3 pb-2">
          <a href="#/" className={navItem(route.name === 'dashboard')}>
            <LayoutDashboard size={16} /> Dasbor
          </a>
          <a href="#/settings" className={navItem(route.name === 'settings')}>
            <Settings size={16} /> Pengaturan
          </a>
        </nav>

        <div className="px-3.5 pb-1 pt-3 text-xs font-medium text-muted">Dokumen Anda</div>
        <div className="thin-scroll min-h-0 flex-1 space-y-0.5 overflow-y-auto px-3 pb-3">
          {docs.length === 0 && <p className="px-2.5 py-2 text-sm text-muted">Belum ada dokumen.</p>}
          {docs.map((d) => {
            const active = route.name === 'editor' && route.id === d.id
            return (
              <a
                key={d.id}
                href={`#${paths.doc(d.id)}`}
                className={`flex items-start gap-2.5 rounded-lg px-2.5 py-1.5 transition-colors ${
                  active ? 'bg-brand/15' : 'hover:bg-surface2'
                }`}
              >
                <FileText size={15} className={`mt-0.5 shrink-0 ${active ? 'text-brand' : 'text-muted'}`} />
                <span className="min-w-0">
                  <span className={`block truncate text-sm ${active ? 'font-medium text-brand' : ''}`}>{d.title}</span>
                  <span className="block text-xs text-muted">{relativeTime(d.updatedAt)}</span>
                </span>
              </a>
            )
          })}
        </div>

        <div className="flex items-center justify-between border-t border-line px-3.5 py-2.5">
          <span className="text-xs text-muted">Tersimpan di perangkat ini</span>
          <button type="button" className="btn-icon h-8 w-8" onClick={toggleTheme} aria-label="Ganti tema" title="Ganti tema">
            {dark ? <Sun size={16} /> : <Moon size={16} />}
          </button>
        </div>
      </aside>
    </>
  )
}
