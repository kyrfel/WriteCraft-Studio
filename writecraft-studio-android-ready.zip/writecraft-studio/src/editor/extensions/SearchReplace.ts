import { Extension } from '@tiptap/core'
import type { Node as PMNode } from '@tiptap/pm/model'
import { Plugin, PluginKey, TextSelection } from '@tiptap/pm/state'
import { Decoration, DecorationSet } from '@tiptap/pm/view'

export interface SearchMatch {
  from: number
  to: number
}
export interface SearchState {
  term: string
  caseSensitive: boolean
  matches: SearchMatch[]
  index: number
}

export const searchKey = new PluginKey<SearchState>('wcSearch')

const EMPTY: SearchState = { term: '', caseSensitive: false, matches: [], index: 0 }

declare module '@tiptap/core' {
  interface Commands<ReturnType> {
    searchReplace: {
      setSearch: (term: string, caseSensitive: boolean) => ReturnType
      stepSearch: (delta: number) => ReturnType
      replaceCurrent: (replacement: string) => ReturnType
      replaceAll: (replacement: string) => ReturnType
      clearSearch: () => ReturnType
    }
  }
}

/** Cari semua kemunculan `term`, per blok teks (menembus batas mark seperti tebal/miring). */
export function findMatches(doc: PMNode, term: string, caseSensitive: boolean): SearchMatch[] {
  if (!term) return []
  const out: SearchMatch[] = []
  doc.descendants((node, pos) => {
    if (!node.isTextblock) return true
    let text = ''
    const map: number[] = []
    node.forEach((child, offset) => {
      if (child.isText && child.text) {
        for (let i = 0; i < child.text.length; i++) map.push(pos + 1 + offset + i)
        text += child.text
      } else {
        map.push(pos + 1 + offset)
        text += '\uFFFC'
      }
    })
    let hay = text
    let needle = term
    if (!caseSensitive) {
      const lowered = text.toLowerCase()
      if (lowered.length === text.length) {
        hay = lowered
        needle = term.toLowerCase()
      }
    }
    let idx = hay.indexOf(needle)
    while (idx !== -1) {
      out.push({ from: map[idx], to: map[idx + needle.length - 1] + 1 })
      idx = hay.indexOf(needle, idx + needle.length)
    }
    return false
  })
  return out
}

export const SearchReplace = Extension.create({
  name: 'searchReplace',

  addProseMirrorPlugins() {
    return [
      new Plugin<SearchState>({
        key: searchKey,
        state: {
          init: () => EMPTY,
          apply(tr, prev, _old, next) {
            const meta = tr.getMeta(searchKey) as (Partial<SearchState> & { index?: number }) | undefined
            if (meta) {
              const term = meta.term ?? prev.term
              const caseSensitive = meta.caseSensitive ?? prev.caseSensitive
              const matches = findMatches(next.doc, term, caseSensitive)
              const n = matches.length
              const raw = meta.index ?? 0
              return { term, caseSensitive, matches, index: n ? ((raw % n) + n) % n : 0 }
            }
            if (tr.docChanged && prev.term) {
              const matches = findMatches(next.doc, prev.term, prev.caseSensitive)
              return { ...prev, matches, index: Math.min(prev.index, Math.max(0, matches.length - 1)) }
            }
            return prev
          },
        },
        props: {
          decorations(state) {
            const s = searchKey.getState(state)
            if (!s || s.matches.length === 0) return DecorationSet.empty
            return DecorationSet.create(
              state.doc,
              s.matches.map((m, i) =>
                Decoration.inline(m.from, m.to, {
                  class: i === s.index ? 'wc-search-match wc-search-current' : 'wc-search-match',
                }),
              ),
            )
          },
        },
      }),
    ]
  },

  addCommands() {
    return {
      setSearch:
        (term: string, caseSensitive: boolean) =>
        ({ tr, dispatch }) => {
          if (dispatch) {
            tr.setMeta(searchKey, { term, caseSensitive, index: 0 })
            const first = findMatches(tr.doc, term, caseSensitive)[0]
            if (first) tr.setSelection(TextSelection.create(tr.doc, first.from, first.to)).scrollIntoView()
          }
          return true
        },

      stepSearch:
        (delta: number) =>
        ({ tr, state, dispatch }) => {
          const s = searchKey.getState(state)
          if (!s || s.matches.length === 0) return false
          const n = s.matches.length
          const index = (((s.index + delta) % n) + n) % n
          if (dispatch) {
            tr.setMeta(searchKey, { index })
            const m = s.matches[index]
            tr.setSelection(TextSelection.create(tr.doc, m.from, m.to)).scrollIntoView()
          }
          return true
        },

      replaceCurrent:
        (replacement: string) =>
        ({ tr, state, dispatch }) => {
          const s = searchKey.getState(state)
          const m = s?.matches[s.index]
          if (!m) return false
          if (dispatch) tr.insertText(replacement, m.from, m.to)
          return true
        },

      replaceAll:
        (replacement: string) =>
        ({ tr, state, dispatch }) => {
          const s = searchKey.getState(state)
          if (!s || s.matches.length === 0) return false
          if (dispatch) {
            // dari belakang ke depan agar posisi sebelumnya tidak bergeser
            for (let i = s.matches.length - 1; i >= 0; i--) {
              tr.insertText(replacement, s.matches[i].from, s.matches[i].to)
            }
          }
          return true
        },

      clearSearch:
        () =>
        ({ tr, dispatch }) => {
          if (dispatch) tr.setMeta(searchKey, { term: '', index: 0 })
          return true
        },
    }
  },
})
