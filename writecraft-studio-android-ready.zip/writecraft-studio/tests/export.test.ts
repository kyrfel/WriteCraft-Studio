import { describe, expect, it } from 'vitest'
import { Packer } from 'docx'
import { buildDocx } from '../src/services/exportDocx'
import { buildPdf } from '../src/services/exportPdf'
import { TEMPLATES } from '../src/templates'
import { makeRecord } from './fixtures'

describe('ekspor DOCX', () => {
  for (const tpl of TEMPLATES) {
    it(`menghasilkan .docx valid untuk template ${tpl.id}`, async () => {
      const buf = await Packer.toBuffer(buildDocx(makeRecord(tpl.id)))
      expect(buf.length).toBeGreaterThan(1000)
      // ZIP signature "PK"
      expect(buf[0]).toBe(0x50)
      expect(buf[1]).toBe(0x4b)
    })
  }

  it('mendukung landscape, header, footer, dan nomor halaman', async () => {
    const rec = makeRecord('laporan')
    rec.settings = { ...rec.settings, orientation: 'landscape', header: 'Rahasia', footer: 'WriteCraft', showPageNumber: true }
    const buf = await Packer.toBuffer(buildDocx(rec))
    expect(buf.length).toBeGreaterThan(1000)
  })
})

describe('ekspor PDF', () => {
  for (const tpl of TEMPLATES) {
    it(`menghasilkan PDF valid untuk template ${tpl.id}`, () => {
      const pdf = buildPdf(makeRecord(tpl.id))
      const head = new TextDecoder().decode(new Uint8Array(pdf.output('arraybuffer')).slice(0, 5))
      expect(head).toBe('%PDF-')
      expect(pdf.getNumberOfPages()).toBeGreaterThanOrEqual(1)
    })
  }

  it('makalah memiliki sampul + beberapa halaman', () => {
    const pdf = buildPdf(makeRecord('makalah'))
    expect(pdf.getNumberOfPages()).toBeGreaterThanOrEqual(3)
  })

  it('memecah dokumen panjang menjadi banyak halaman', () => {
    const rec = makeRecord('laporan')
    const long = Array.from({ length: 120 }, (_, n) => ({
      type: 'paragraph',
      content: [{ type: 'text', text: `Paragraf nomor ${n} dengan teks yang cukup panjang untuk membungkus baris. `.repeat(4) }],
    }))
    rec.content = { type: 'doc', content: long }
    const pdf = buildPdf(rec)
    expect(pdf.getNumberOfPages()).toBeGreaterThan(5)
  })
})
