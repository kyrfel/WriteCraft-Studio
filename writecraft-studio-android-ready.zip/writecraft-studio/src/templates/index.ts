import type { DocCategory, DocNode, DocSettings } from '../types'
import { EMPTY_DOC } from '../utils/doc'
import { b, blank, center, h, hr, i, justify, ol, p, pageBreak, right, t, table, ul } from './helpers'

export interface DocTemplate {
  id: string
  name: string
  description: string
  category: DocCategory
  /** Judul awal dokumen. */
  title: string
  /** Penimpa pengaturan dokumen (font, spasi, margin, dst.). */
  settings?: Partial<DocSettings>
  build: () => DocNode
}

const doc = (...content: DocNode[]): DocNode => ({ type: 'doc', content })

export const TEMPLATES: DocTemplate[] = [
  {
    id: 'blank',
    name: 'Dokumen kosong',
    description: 'Mulai dari halaman putih.',
    category: 'umum',
    title: 'Dokumen tanpa judul',
    build: () => EMPTY_DOC,
  },
  {
    id: 'surat',
    name: 'Surat resmi',
    description: 'Kop, nomor, perihal, isi, dan tanda tangan.',
    category: 'surat',
    title: 'Surat resmi',
    settings: { fontFamily: 'Times New Roman', fontSize: 12, lineHeight: 1.15 },
    build: () =>
      doc(
        p([b('NAMA INSTANSI / PERUSAHAAN')], center),
        p('Jl. Contoh Alamat No. 1, Kota, Kode Pos 12345', center),
        p('Telepon (021) 000-0000 · Surel info@contoh.id', center),
        hr(),
        p('Kota, 5 November 2026', right),
        p('Nomor\t: 001/XX/2026'),
        p('Lampiran\t: -'),
        p('Perihal\t: Isi perihal surat'),
        blank(),
        p('Yth. Nama Penerima'),
        p('di tempat'),
        blank(),
        p('Dengan hormat,'),
        p(
          'Tuliskan paragraf pembuka yang menjelaskan maksud dan tujuan surat ini dengan singkat dan jelas.',
          justify,
        ),
        p(
          'Paragraf kedua berisi uraian, permohonan, atau informasi pendukung yang dibutuhkan oleh penerima surat.',
          justify,
        ),
        p('Demikian surat ini kami sampaikan. Atas perhatian dan kerja samanya, kami ucapkan terima kasih.', justify),
        blank(),
        p('Hormat kami,'),
        blank(),
        blank(),
        p([b('Nama Penandatangan')]),
        p('Jabatan'),
      ),
  },
  {
    id: 'laporan',
    name: 'Laporan',
    description: 'Ringkasan, pendahuluan, hasil, dan rekomendasi.',
    category: 'laporan',
    title: 'Laporan',
    settings: { showPageNumber: true },
    build: () =>
      doc(
        h(1, 'Judul Laporan'),
        p([i('Disusun oleh Nama Penyusun · November 2026')]),
        h(2, 'Ringkasan Eksekutif'),
        p('Rangkum temuan utama dan kesimpulan laporan dalam satu atau dua paragraf.'),
        h(2, 'Pendahuluan'),
        p('Jelaskan latar belakang, tujuan, dan ruang lingkup laporan.'),
        h(2, 'Hasil dan Pembahasan'),
        p('Uraikan data, temuan, dan analisis. Gunakan tabel untuk menyajikan angka:'),
        table(['Indikator', 'Target', 'Capaian'], [
          ['Indikator 1', '100', '92'],
          ['Indikator 2', '50', '57'],
          ['Indikator 3', '20', '20'],
        ]),
        blank(),
        h(2, 'Kesimpulan'),
        p('Tuliskan kesimpulan berdasarkan hasil di atas.'),
        h(2, 'Rekomendasi'),
        ol(['Rekomendasi pertama.', 'Rekomendasi kedua.', 'Rekomendasi ketiga.']),
      ),
  },
  {
    id: 'makalah',
    name: 'Makalah',
    description: 'Sampul, bab, dan daftar pustaka.',
    category: 'makalah',
    title: 'Makalah',
    settings: { fontFamily: 'Times New Roman', fontSize: 12, lineHeight: 1.5, showPageNumber: true },
    build: () =>
      doc(
        blank(),
        blank(),
        h(1, 'JUDUL MAKALAH', center),
        p('Diajukan untuk memenuhi tugas mata kuliah ...', center),
        blank(),
        blank(),
        p([b('Disusun oleh:')], center),
        p('Nama Penyusun (NIM)', center),
        blank(),
        blank(),
        p([b('NAMA PROGRAM STUDI')], center),
        p([b('NAMA UNIVERSITAS')], center),
        p([b('2026')], center),
        pageBreak(),
        h(2, 'KATA PENGANTAR', center),
        p('Puji syukur kami panjatkan atas selesainya makalah ini. Makalah ini disusun untuk ...', justify),
        pageBreak(),
        h(2, 'BAB I — PENDAHULUAN', center),
        h(3, '1.1 Latar Belakang'),
        p('Uraikan latar belakang masalah.', justify),
        h(3, '1.2 Rumusan Masalah'),
        ol(['Rumusan masalah pertama?', 'Rumusan masalah kedua?']),
        h(3, '1.3 Tujuan'),
        p('Uraikan tujuan penulisan makalah.', justify),
        h(2, 'BAB II — PEMBAHASAN', center),
        p('Uraikan pembahasan dan landasan teori.', justify),
        h(2, 'BAB III — PENUTUP', center),
        h(3, '3.1 Kesimpulan'),
        p('Tuliskan kesimpulan.', justify),
        h(3, '3.2 Saran'),
        p('Tuliskan saran.', justify),
        h(2, 'DAFTAR PUSTAKA', center),
        p('Penulis, A. (Tahun). Judul buku. Kota: Penerbit.'),
      ),
  },
  {
    id: 'proposal',
    name: 'Proposal',
    description: 'Latar belakang, rencana kegiatan, dan anggaran.',
    category: 'proposal',
    title: 'Proposal',
    settings: { showPageNumber: true },
    build: () =>
      doc(
        h(1, 'Proposal Kegiatan'),
        p([i('Diajukan oleh Nama Pengaju kepada Pihak Penerima')]),
        h(2, 'Latar Belakang'),
        p('Jelaskan masalah atau peluang yang melatarbelakangi kegiatan ini.'),
        h(2, 'Tujuan'),
        ul(['Tujuan pertama', 'Tujuan kedua', 'Tujuan ketiga']),
        h(2, 'Rencana Kegiatan'),
        table(['Tahap', 'Kegiatan', 'Waktu'], [
          ['1', 'Persiapan', 'Minggu 1'],
          ['2', 'Pelaksanaan', 'Minggu 2–4'],
          ['3', 'Evaluasi dan pelaporan', 'Minggu 5'],
        ]),
        blank(),
        h(2, 'Rencana Anggaran'),
        table(['Pos', 'Rincian', 'Biaya (Rp)'], [
          ['Perlengkapan', 'Contoh rincian', '1.000.000'],
          ['Konsumsi', 'Contoh rincian', '500.000'],
          ['Total', '', '1.500.000'],
        ]),
        blank(),
        h(2, 'Penutup'),
        p('Demikian proposal ini kami ajukan. Kami berharap dukungan dari Bapak/Ibu.'),
      ),
  },
  {
    id: 'resume',
    name: 'Resume',
    description: 'Profil singkat, pengalaman, pendidikan, keahlian.',
    category: 'resume',
    title: 'Resume',
    settings: { margins: { top: 2, bottom: 2, left: 2.2, right: 2.2 }, fontSize: 11 },
    build: () =>
      doc(
        h(1, 'Nama Lengkap'),
        p('Kota · +62 800 0000 0000 · nama@surel.com · linkedin.com/in/nama'),
        hr(),
        h(2, 'Profil'),
        p('Dua atau tiga kalimat tentang pengalaman, keahlian utama, dan tujuan karier Anda.'),
        h(2, 'Pengalaman Kerja'),
        p([b('Jabatan — Nama Perusahaan'), t('  (2022 – sekarang)')]),
        ul(['Pencapaian yang terukur, misalnya meningkatkan penjualan 20%.', 'Tanggung jawab utama Anda.']),
        h(2, 'Pendidikan'),
        p([b('Nama Universitas'), t(' — Program Studi (2018 – 2022)')]),
        h(2, 'Keahlian'),
        ul(['Keahlian 1', 'Keahlian 2', 'Keahlian 3']),
      ),
  },
  {
    id: 'catatan',
    name: 'Catatan',
    description: 'Catatan rapat atau ide cepat.',
    category: 'catatan',
    title: 'Catatan',
    build: () =>
      doc(
        h(2, 'Catatan'),
        p([i('Tanggal: ')]),
        h(3, 'Poin penting'),
        ul(['', '', '']),
        h(3, 'Tindak lanjut'),
        ol(['']),
      ),
  },
]

export const getTemplate = (id: string): DocTemplate => TEMPLATES.find((x) => x.id === id) ?? TEMPLATES[0]
