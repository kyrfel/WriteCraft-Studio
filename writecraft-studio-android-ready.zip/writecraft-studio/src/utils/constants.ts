import type { DocCategory } from '../types'

export const CATEGORIES: { id: DocCategory; label: string }[] = [
  { id: 'umum', label: 'Umum' },
  { id: 'surat', label: 'Surat' },
  { id: 'laporan', label: 'Laporan' },
  { id: 'makalah', label: 'Makalah' },
  { id: 'proposal', label: 'Proposal' },
  { id: 'resume', label: 'Resume' },
  { id: 'catatan', label: 'Catatan' },
]

export const categoryLabel = (id: DocCategory): string =>
  CATEGORIES.find((c) => c.id === id)?.label ?? 'Umum'

export const FONT_FAMILIES: { name: string; stack: string }[] = [
  { name: 'Arial', stack: 'Arial, Helvetica, sans-serif' },
  { name: 'Calibri', stack: 'Calibri, Carlito, Arial, sans-serif' },
  { name: 'Georgia', stack: 'Georgia, serif' },
  { name: 'Times New Roman', stack: '"Times New Roman", Times, serif' },
  { name: 'Verdana', stack: 'Verdana, Geneva, sans-serif' },
  { name: 'Tahoma', stack: 'Tahoma, Geneva, sans-serif' },
  { name: 'Trebuchet MS', stack: '"Trebuchet MS", Helvetica, sans-serif' },
  { name: 'Courier New', stack: '"Courier New", Courier, monospace' },
]

export const stackFor = (name: string): string =>
  FONT_FAMILIES.find((f) => f.name === name)?.stack ?? `"${name}", sans-serif`

export const FONT_SIZES = [8, 9, 10, 11, 12, 14, 16, 18, 20, 24, 28, 32, 36, 48, 72]

export const LINE_HEIGHTS = [1, 1.15, 1.5, 2, 2.5, 3]

/** Faktor tinggi baris alami font terhadap ukurannya (dipakai editor & ekspor agar konsisten). */
export const NATURAL_LINE = 1.2

/** Karakter khusus yang aman untuk DOCX maupun PDF (WinAnsi). */
export const SPECIAL_CHARS = [
  '©', '®', '™', '§', '¶', '°', '±', '×', '÷', '€', '£', '¥', '¢', '«', '»', '–', '—', '…', '•', '¼', '½', '¾',
  '²', '³', 'µ', '†', '‡', '‰', '¿', '¡', '‘', '’', '“', '”', 'é', 'è', 'ñ', 'ü', 'ö', 'ä', 'ç', 'ß',
]

export const COLOR_SWATCHES = [
  '#000000', '#434343', '#7f7f7f', '#b7b7b7', '#ffffff',
  '#c0392b', '#e67e22', '#f1c40f', '#27ae60', '#16a085',
  '#2980b9', '#8e44ad', '#d81b60', '#0e5a66', '#795548',
]

export const HIGHLIGHT_SWATCHES = [
  '#fff176', '#ffcc80', '#ef9a9a', '#f48fb1', '#ce93d8',
  '#90caf9', '#80deea', '#a5d6a7', '#e6ee9c', '#d7ccc8',
]
