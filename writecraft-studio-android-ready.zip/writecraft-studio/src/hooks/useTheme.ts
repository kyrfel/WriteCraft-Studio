import { useEffect } from 'react'
import { updateSettings } from '../services/settings'
import { useAppSettings } from './useAppSettings'

/** Terapkan kelas `dark` pada <html> sesuai pilihan tema (terang/gelap/sistem). */
export function useThemeEffect(): void {
  const { theme } = useAppSettings()
  useEffect(() => {
    const mq = window.matchMedia('(prefers-color-scheme: dark)')
    const apply = () => {
      const dark = theme === 'dark' || (theme === 'system' && mq.matches)
      document.documentElement.classList.toggle('dark', dark)
    }
    apply()
    mq.addEventListener('change', apply)
    return () => mq.removeEventListener('change', apply)
  }, [theme])
}

export function useIsDark(): boolean {
  const { theme } = useAppSettings()
  return theme === 'dark' || (theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches)
}

export function toggleTheme(): void {
  const dark = document.documentElement.classList.contains('dark')
  updateSettings({ theme: dark ? 'light' : 'dark' })
}
