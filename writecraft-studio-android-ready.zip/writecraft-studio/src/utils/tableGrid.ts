import type { DocNode } from '../types'

/** Hitung jumlah kolom grid dan proporsi lebar tiap kolom dari baris pertama tabel. */
export function tableGrid(table: DocNode): { cols: number; fractions: number[] } {
  const firstRow = table.content?.[0]
  const widths: (number | null)[] = []
  for (const cell of firstRow?.content ?? []) {
    const span = Number(cell.attrs?.colspan ?? 1) || 1
    const cw = cell.attrs?.colwidth as number[] | null | undefined
    for (let i = 0; i < span; i++) widths.push(cw && cw[i] ? cw[i] : null)
  }
  if (widths.length === 0) return { cols: 1, fractions: [1] }
  const known = widths.filter((w): w is number => w !== null)
  const avg = known.length ? known.reduce((a, b) => a + b, 0) / known.length : 1
  const filled = widths.map((w) => w ?? avg)
  const sum = filled.reduce((a, b) => a + b, 0)
  return { cols: widths.length, fractions: filled.map((w) => w / sum) }
}
