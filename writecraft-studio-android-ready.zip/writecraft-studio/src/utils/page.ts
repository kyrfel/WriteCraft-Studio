import type { DocSettings, PageSize } from '../types'

/** Ukuran kertas potret dalam cm. */
export const PAGE_SIZES: Record<PageSize, { label: string; width: number; height: number }> = {
  A4: { label: 'A4 (21 × 29,7 cm)', width: 21, height: 29.7 },
  A5: { label: 'A5 (14,8 × 21 cm)', width: 14.8, height: 21 },
  Letter: { label: 'Letter (21,59 × 27,94 cm)', width: 21.59, height: 27.94 },
}

export const CM_TO_PX = 96 / 2.54
export const CM_TO_PT = 72 / 2.54
export const CM_TO_TWIP = 1440 / 2.54

/** Ukuran halaman (cm) setelah orientasi diterapkan. */
export function getPageDims(s: Pick<DocSettings, 'pageSize' | 'orientation'>): { width: number; height: number } {
  const base = PAGE_SIZES[s.pageSize]
  return s.orientation === 'landscape'
    ? { width: base.height, height: base.width }
    : { width: base.width, height: base.height }
}

export function getContentSizeCm(s: DocSettings): { width: number; height: number } {
  const d = getPageDims(s)
  return {
    width: Math.max(2, d.width - s.margins.left - s.margins.right),
    height: Math.max(2, d.height - s.margins.top - s.margins.bottom),
  }
}
