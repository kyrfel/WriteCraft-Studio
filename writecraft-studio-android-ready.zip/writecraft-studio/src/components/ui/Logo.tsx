export function LogoMark({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden="true" className="shrink-0">
      <rect width="64" height="64" rx="14" fill="#0e5a66" />
      <rect x="10" y="40" width="44" height="9" rx="2" fill="#f2cf4a" opacity=".95" />
      <path d="M12 16l9 30 11-22 11 22 9-30" fill="none" stroke="#fff" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

export function Logo() {
  return (
    <span className="flex items-center gap-2.5">
      <LogoMark />
      <span className="font-serif text-[17px] font-semibold tracking-tight">WriteCraft Studio</span>
    </span>
  )
}
