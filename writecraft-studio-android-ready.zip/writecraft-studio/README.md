# WriteCraft Studio

Editor dokumen modern yang berjalan sepenuhnya di browser. Tulis, edit, simpan, lalu ekspor ke **DOCX** dan **PDF** — tanpa server, tanpa akun, tanpa API key.

> Tambahkan tangkapan layar Anda di `docs/screenshots/` lalu ganti placeholder di bawah.

| Dasbor | Editor | Mode gelap |
| --- | --- | --- |
| ![Dasbor](docs/screenshots/dashboard.png) | ![Editor](docs/screenshots/editor.png) | ![Mode gelap](docs/screenshots/dark.png) |

## Fitur

**Penulisan**
- Tebal, miring, garis bawah, coret, subskrip/superskrip, font, ukuran font, warna teks, sorot teks
- Rata kiri/tengah/kanan/kiri-kanan, spasi baris, daftar poin & bernomor (bertingkat), indentasi
- Judul 1–3, kutipan, blok kode, undo/redo, salin/potong/tempel, pilih semua
- Cari dan ganti (Ctrl+F), penghitung kata & karakter, zoom kanvas

**Tata letak halaman**
- Ukuran A4, A5, Letter; potret/lanskap; margin atas/bawah/kiri/kanan
- Pemisah halaman, header, footer, nomor halaman

**Sisipkan**
- Gambar (dari file, tempel, atau seret; bisa diubah ukuran & posisinya), tabel (tambah/hapus baris/kolom, gabung sel, header)
- Tautan, garis horizontal, tanggal hari ini, karakter khusus

**Dokumen**
- Dasbor: sambutan, dokumen baru, dokumen terbaru, pencarian, kategori, 7 template (surat resmi, laporan, makalah, proposal, resume, catatan, kosong)
- Simpan otomatis ke IndexedDB, ganti nama, duplikat, hapus, buka, unduh
- Impor `.docx` (via Mammoth), ekspor `.docx` dan `.pdf`
- Cadangan/pemulihan semua dokumen sebagai JSON
- Mode terang/gelap/ikuti sistem, responsif untuk desktop dan ponsel

## Teknologi

React 18 · TypeScript · Vite · Tailwind CSS · TipTap (ProseMirror) · Lucide Icons ·
[docx](https://github.com/dolanmiu/docx) (DOCX) · [jsPDF](https://github.com/parallax/jsPDF) (PDF) ·
[Mammoth.js](https://github.com/mwilliamson/mammoth.js) (baca DOCX) · [idb](https://github.com/jakearchibald/idb) (IndexedDB)

Semua dependensi open-source berlisensi permisif (MIT/BSD/Apache-2.0). Tidak ada aset berhak cipta pihak ketiga; logo dan ikon favicon dibuat khusus untuk proyek ini.

## Instalasi

Prasyarat: **Node.js 18 atau lebih baru**.

```bash
npm install
npm run dev      # server pengembangan di http://localhost:5173
npm run build    # type-check + build produksi ke folder dist/
npm run preview  # cek hasil build secara lokal
npm test         # uji unit & ekspor (Vitest)
npm run typecheck
```

## Panduan pengembangan

```
writecraft-studio/
├── public/                  favicon
├── src/
│   ├── components/
│   │   ├── ui/              Modal, Dropdown (portal), Toast, Logo
│   │   ├── layout/          AppShell, Sidebar, PageHeader
│   │   └── dashboard/       kartu dokumen, kartu & miniatur template
│   ├── pages/               DashboardPage, EditorPage, SettingsPage
│   ├── editor/
│   │   ├── extensions/      FontSize, ParagraphStyle, PageBreak, ResizableImage, SearchReplace
│   │   ├── extensions.ts    daftar ekstensi TipTap (dipakai editor & impor DOCX)
│   │   ├── Toolbar.tsx  FindReplace.tsx  DocumentSettingsDialog.tsx  EditorWorkspace.tsx
│   ├── services/
│   │   ├── storage.ts       IndexedDB (CRUD, duplikat, cadangan)
│   │   ├── exportDocx.ts    JSON TipTap → DOCX
│   │   ├── exportPdf.ts     JSON TipTap → PDF (tata letak sendiri di atas jsPDF)
│   │   ├── importDocx.ts    DOCX → HTML (Mammoth) → JSON TipTap
│   │   ├── imageUtils.ts    rasterisasi gambar untuk ekspor
│   │   ├── settings.ts documents.ts download.ts
│   ├── hooks/               useAutosave, useDocuments, useHashRoute, useTheme, ...
│   ├── templates/           7 template dokumen
│   ├── utils/  types/  styles/
│   └── App.tsx  main.tsx
├── tests/                   Vitest (utilitas + ekspor DOCX/PDF)
├── .github/workflows/ci.yml typecheck + test + build
└── README.md  LICENSE  .gitignore  .env.example
```

### Cara kerja

```
TipTap editor ──getJSON()──▶ DocumentRecord ──▶ IndexedDB (autosave)
                                   │
                    ┌──────────────┴──────────────┐
              exportDocx.ts                   exportPdf.ts
         (objek `docx` → .docx)        (tata letak + jsPDF → .pdf)
```

Isi dokumen disimpan sebagai **JSON TipTap**, satu sumber data untuk editor, penyimpanan, dan kedua eksportir. Library ekspor dimuat saat dibutuhkan (code splitting) agar aplikasi cepat dibuka.

Rute memakai hash (`#/`, `#/doc/:id`, `#/settings`) sehingga hasil build bisa dihosting statis di mana saja, termasuk GitHub Pages.

## Batasan yang perlu diketahui

- **PDF memakai font bawaan PDF** (Helvetica/Times/Courier). Aksara Latin dan tanda baca umum aman; karakter di luar itu (mis. kanji, emoji) tampil sebagai `?`. Font Arial/Calibri/Verdana dipetakan ke Helvetica, Georgia/Times ke Times, Courier New ke Courier. Untuk mendukung font kustom, embed TTF melalui `doc.addFont` di `exportPdf.ts`.
- **Garis halaman di editor adalah perkiraan.** Pemisahan halaman final dihitung saat ekspor, dan hasil DOCX dapat sedikit berbeda dengan PDF karena Word menata ulang teks dengan fontnya sendiri.
- **Impor DOCX** mempertahankan struktur (judul, paragraf, daftar, tabel, gambar, tebal/miring), tetapi tidak membawa font, warna, dan perataan dari berkas asal.
- Gambar dari URL eksternal bisa gagal diekspor karena kebijakan CORS browser; gambar yang disisipkan dari perangkat selalu aman.
- Data tersimpan **hanya di browser perangkat ini**. Gunakan *Pengaturan → Unduh cadangan* secara berkala.

## Deploy ke GitHub Pages (opsional)

`vite.config.ts` memakai `base: './'`, jadi isi folder `dist/` dapat langsung dipublikasikan ke GitHub Pages atau hosting statis lain.

## Keamanan

Tidak ada API key, password, atau rahasia dalam repositori. `.env*` sudah masuk `.gitignore` (kecuali `.env.example`). Tautan `javascript:`/`data:` ditolak di dialog tautan.

## Lisensi

[MIT](LICENSE)

## Build APK Android melalui GitHub Actions

Proyek ini adalah aplikasi React + Vite. Untuk membuat aplikasi Android, proyek dibungkus dengan Capacitor.

1. Unggah seluruh isi repository ini ke GitHub (termasuk folder `.github`).
2. Pastikan branch utama bernama `main`.
3. Buka tab **Actions** pada repository GitHub.
4. Pilih workflow **Build Android APK** lalu klik **Run workflow**. Workflow juga berjalan otomatis setiap ada push ke `main`.
5. Setelah workflow selesai dengan status hijau, buka hasil run tersebut.
6. Pada bagian **Artifacts**, unduh `WriteCraft-Studio-APK` dan ekstrak file ZIP untuk mendapatkan `app-debug.apk`.

Workflow membuat proyek Android sementara menggunakan Capacitor 6 dan menghasilkan APK debug untuk pengujian. APK debug bukan rilis Play Store; untuk distribusi publik diperlukan APK/AAB release yang ditandatangani dengan keystore milik pemilik aplikasi.

**Catatan:** workflow membutuhkan akses internet saat memasang paket npm dan mengambil dependensi Android/Gradle. Jangan unggah file rahasia atau keystore ke repository publik.
