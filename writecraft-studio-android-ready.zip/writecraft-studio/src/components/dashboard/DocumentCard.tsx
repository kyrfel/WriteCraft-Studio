import { Copy, Download, EllipsisVertical, FileText, FolderOpen, Pencil, Trash2 } from 'lucide-react'
import type { DocumentRecord } from '../../types'
import type { ExportKind } from '../../services/download'
import { categoryLabel } from '../../utils/constants'
import { previewText } from '../../utils/doc'
import { relativeTime } from '../../utils/format'
import { Dropdown } from '../ui/Dropdown'

interface Props {
  doc: DocumentRecord
  onOpen: () => void
  onRename: () => void
  onDuplicate: () => void
  onDelete: () => void
  onExport: (kind: ExportKind) => void
}

export function DocumentCard({ doc, onOpen, onRename, onDuplicate, onDelete, onExport }: Props) {
  const preview = previewText(doc.content, 220)
  return (
    <div className="group flex flex-col overflow-hidden rounded-xl border border-line bg-surface transition-colors hover:border-brand/50">
      <button type="button" onClick={onOpen} className="block text-left" aria-label={`Buka ${doc.title}`}>
        <div className="h-36 overflow-hidden border-b border-line bg-white px-4 pt-3.5">
          <p className="line-clamp-6 font-serif text-[10.5px] leading-[1.55] text-slate-600">
            {preview || <span className="italic text-slate-400">Dokumen kosong</span>}
          </p>
        </div>
      </button>
      <div className="flex items-start gap-2 p-3">
        <div className="min-w-0 flex-1">
          <button type="button" onClick={onOpen} className="block w-full truncate text-left text-sm font-semibold hover:text-brand">
            {doc.title}
          </button>
          <p className="mt-0.5 flex items-center gap-1.5 text-xs text-muted">
            <span className="rounded bg-surface2 px-1.5 py-px">{categoryLabel(doc.category)}</span>
            <span>{relativeTime(doc.updatedAt)}</span>
          </p>
        </div>
        <Dropdown
          label="Menu dokumen"
          className="btn-icon -mr-1.5 -mt-1 h-8 w-8 shrink-0"
          align="right"
          trigger={<EllipsisVertical size={16} />}
        >
          {(close) => {
            const act = (fn: () => void) => () => {
              close()
              fn()
            }
            return (
              <div className="min-w-[12rem]">
                <button type="button" className="menu-item" onClick={act(onOpen)}><FolderOpen size={15} /> Buka</button>
                <button type="button" className="menu-item" onClick={act(onRename)}><Pencil size={15} /> Ganti nama</button>
                <button type="button" className="menu-item" onClick={act(onDuplicate)}><Copy size={15} /> Duplikat</button>
                <div className="my-1 h-px bg-line" />
                <button type="button" className="menu-item" onClick={act(() => onExport('docx'))}><Download size={15} /> Unduh DOCX</button>
                <button type="button" className="menu-item" onClick={act(() => onExport('pdf'))}><FileText size={15} /> Unduh PDF</button>
                <div className="my-1 h-px bg-line" />
                <button type="button" className="menu-item text-red-600" onClick={act(onDelete)}><Trash2 size={15} /> Hapus</button>
              </div>
            )
          }}
        </Dropdown>
      </div>
    </div>
  )
}
