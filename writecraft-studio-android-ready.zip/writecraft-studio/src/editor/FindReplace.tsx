import { useEffect, useState } from 'react'
import type { Editor } from '@tiptap/core'
import { ChevronDown, ChevronUp, X } from 'lucide-react'
import { useEditorTick } from '../hooks/useEditorTick'
import { searchKey } from './extensions/SearchReplace'

export function FindReplace({ editor, onClose }: { editor: Editor; onClose: () => void }) {
  useEditorTick(editor)
  const [term, setTerm] = useState(() => {
    const { from, to } = editor.state.selection
    return from !== to && to - from < 60 ? editor.state.doc.textBetween(from, to, ' ') : ''
  })
  const [replacement, setReplacement] = useState('')
  const [caseSensitive, setCaseSensitive] = useState(false)

  useEffect(() => {
    editor.commands.setSearch(term, caseSensitive)
  }, [editor, term, caseSensitive])

  useEffect(() => () => void editor.commands.clearSearch(), [editor])

  const state = searchKey.getState(editor.state)
  const total = state?.matches.length ?? 0
  const status = total ? `${(state?.index ?? 0) + 1} / ${total}` : term ? 'Tidak ada hasil' : ''

  return (
    <div className="flex flex-wrap items-center gap-2 border-b border-line bg-surface px-3 py-2" role="search">
      <input
        className="input h-8 w-40 flex-1 sm:w-48 sm:flex-none"
        placeholder="Cari"
        aria-label="Cari teks"
        autoFocus
        value={term}
        onChange={(e) => setTerm(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Enter') editor.commands.stepSearch(e.shiftKey ? -1 : 1)
          if (e.key === 'Escape') onClose()
        }}
      />
      <input
        className="input h-8 w-40 flex-1 sm:w-48 sm:flex-none"
        placeholder="Ganti dengan"
        aria-label="Teks pengganti"
        value={replacement}
        onChange={(e) => setReplacement(e.target.value)}
        onKeyDown={(e) => e.key === 'Escape' && onClose()}
      />
      <span className="min-w-[5.5rem] text-xs text-muted" aria-live="polite">{status}</span>
      <div className="flex items-center gap-1">
        <button type="button" className="tb-btn" title="Sebelumnya (Shift+Enter)" aria-label="Hasil sebelumnya" onClick={() => editor.commands.stepSearch(-1)}>
          <ChevronUp size={16} />
        </button>
        <button type="button" className="tb-btn" title="Berikutnya (Enter)" aria-label="Hasil berikutnya" onClick={() => editor.commands.stepSearch(1)}>
          <ChevronDown size={16} />
        </button>
        <button
          type="button"
          className="tb-btn text-xs font-semibold"
          title="Peka huruf besar/kecil"
          aria-label="Peka huruf besar/kecil"
          data-active={caseSensitive ? 'true' : undefined}
          onClick={() => setCaseSensitive((v) => !v)}
        >
          Aa
        </button>
      </div>
      <button type="button" className="btn btn-subtle h-8 px-2.5" disabled={!total} onClick={() => editor.commands.replaceCurrent(replacement)}>
        Ganti
      </button>
      <button type="button" className="btn btn-subtle h-8 px-2.5" disabled={!total} onClick={() => editor.commands.replaceAll(replacement)}>
        Ganti semua
      </button>
      <button type="button" className="tb-btn ml-auto" aria-label="Tutup pencarian" onClick={onClose}>
        <X size={16} />
      </button>
    </div>
  )
}
