/** Node dokumen (kompatibel dengan JSONContent milik TipTap). */
export interface DocNode {
  type?: string
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  attrs?: Record<string, any>
  content?: DocNode[]
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  marks?: { type: string; attrs?: Record<string, any> }[]
  text?: string
}

export type PageSize = 'A4' | 'A5' | 'Letter'
export type Orientation = 'portrait' | 'landscape'

/** Margin dalam sentimeter. */
export interface Margins {
  top: number
  bottom: number
  left: number
  right: number
}

export type DocCategory = 'umum' | 'surat' | 'laporan' | 'makalah' | 'proposal' | 'resume' | 'catatan'

export interface DocSettings {
  pageSize: PageSize
  orientation: Orientation
  margins: Margins
  fontFamily: string
  /** Ukuran font dasar dalam pt. */
  fontSize: number
  /** Kelipatan spasi baris (1 = tunggal). */
  lineHeight: number
  header: string
  footer: string
  showPageNumber: boolean
}

export interface DocumentRecord {
  id: string
  title: string
  category: DocCategory
  content: DocNode
  settings: DocSettings
  createdAt: number
  updatedAt: number
}

export type ThemeMode = 'light' | 'dark' | 'system'

export interface AppSettings {
  theme: ThemeMode
  defaultPageSize: PageSize
  defaultOrientation: Orientation
  defaultFontFamily: string
  defaultFontSize: number
  defaultLineHeight: number
  /** Jeda autosave dalam milidetik. */
  autosaveDelay: number
}
