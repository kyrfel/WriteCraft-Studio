/// <reference types="vite/client" />

declare module 'mammoth/mammoth.browser' {
  interface Message {
    type: string
    message: string
  }
  interface ConvertResult {
    value: string
    messages: Message[]
  }
  const mammoth: {
    convertToHtml(input: { arrayBuffer: ArrayBuffer }): Promise<ConvertResult>
  }
  export default mammoth
}
